# Changelog

## [v1.0.1] — Official PANDA BAMBOO Brand & Mascot Identity
- Adopted exact game name **PANDA BAMBOO** across title lockup, HTML metadata, Web App Manifest, and UI.
- Integrated uploaded green-scarf Panda mascot (`public/assets/aistudio/file_0000000097b88211ac13361eefffe4f0_c2fcc832.png`) across App Icon, Loading Screen, Main Menu, Pause/Settings header badges, and Game Over Screen.
- Updated in-game Canvas Panda character to preserve the mascot's flowing green scarf, spiky head fur tuft, and warm paw pads, plus added wooden fence posts along the forest trail.

## [v1.0.0] — First Public Release
- Added complete bilingual support (`English` / `বাংলা`) across all menus, HUD, modals, and funny Game Over reactions.
- Added Loading Screen with generated Bamboo Forest key-art illustration and bespoke `PANDA BASH` SVG lockup.
- Added How to Play modal explaining controls, obstacle types, and bamboo scoring.
- Added optional On-Screen Mobile Touch Controls toggle in Settings.
- Configured `vite.config.ts` with `base: './'` for zero-config GitHub Pages static hosting.
- Added `README.md` with step-by-step Android GitHub Pages deployment guide, `PROJECT_STATUS.md`, and `RESUME_PROMPT.txt`.

## [v0.5.0] — Audio & Animation
- Implemented procedural Web Audio API engine (`src/game/audio.ts`) with 5 musical states (Menu Intro, Gameplay Loop, High-Speed Arcade Layer, Game Over, New Record Fanfare) and 12+ SFX.
- Added animated Panda squash-and-stretch, trailing headband ribbons, footstep sync, pooled dust/leaf/sparkle particles, hitstop freeze frame, and decaying camera shake.

## [v0.4.0] — Score & Difficulty
- Implemented dynamic speed ramp (`1.0x` to `2.55x`), combo multiplier system, and New Record in-run celebration.
- Implemented safe `localStorage` persistence (`src/game/storage.ts`) for high scores, total bamboo, and audio/language settings.

## [v0.3.0] — Collectibles & Obstacles
- Implemented 6 obstacle types (`small_rock`, `large_rock`, `fallen_bamboo`, `wooden_log`, `tree_roots`, `high_bamboo_gate`) with fair passable pattern spawning.
- Added green bamboo (`+10`) and golden lucky bamboo (`+50`) collectibles.

## [v0.2.0] — Character & Movement
- Built 3-lane perspective Canvas renderer (`src/game/renderer.ts`) with cartoon Panda animations for idle, run, jump, slide, and collision.
- Added responsive swipe gestures, keyboard input (`WASD`/`Arrows`/`Space`/`Esc`), input buffering, and airborne fast-fall.

## [v0.1.0] — Initial Prototype
- Initialized PANDA BASH architecture (`types.ts`, `engine.ts`, `App.tsx`, `Screens.tsx`) with `requestAnimationFrame` loop and clamped delta-time.
