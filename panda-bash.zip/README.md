# PANDA BAMBOO 🐼🎋

A vibrant, responsive 2D Cartoon Endless Runner web game built with HTML5 Canvas, TypeScript, React, Tailwind CSS, and procedural Web Audio synthesis.

## Features

- **3-Lane Endless Runner**: Smooth lane switching, jump physics with input buffering, belly-slide & fast-fall mechanics.
- **Dynamic Bamboo Forest**: Multi-layer parallax sky, misty mountains, scrolling bamboo stalks, 3-lane dirt track, dust & leaf particle bursts, and camera shake + hitstop feedback.
- **6 Obstacle Types**:
  - Small Rocks (`jump` / `switch`)
  - Large Rocks (`switch` lane)
  - Fallen Bamboo (`jump` / `switch`)
  - Wooden Logs (`jump` / `switch`)
  - Tree Roots (`jump` / `switch`)
  - Hanging Bamboo Gates (`slide` / `switch`)
- **Bamboo Collectibles**: Green bamboo (`+10` pts) & rare Golden Lucky Bamboo (`+50` pts, `5x` bamboo) with combo multipliers.
- **Complete Procedural Audio System (Web Audio API)**:
  - **Original Synthesized Music**: Main Menu Intro (bamboo flute + marimba), Gameplay Background Loop, High-Speed Cheerful Arcade Intensity Layer, Game Over Jingle, and New High Score Celebration Fanfare.
  - **12+ Original Sound Effects**: Footsteps synced to stride, bamboo collect/crunch/pop, jump, slide, lane switch, collision thud + funny dizzy reaction, countdown ticks, pause/resume chimes, and UI clicks.
  - **No External Broken Audio URLs**: All music and SFX are synthesized in real time via Web Audio API—100% self-contained and offline-ready.
- **Bilingual Support**: Instant switching between **English** and **বাংলা (Bengali)**.
- **Mobile & Desktop Ready**: Touch swipe gestures, optional on-screen touch buttons, keyboard controls (`A/D`, `Arrows`, `W/Up/Space`, `S/Down`, `Esc/P`), High-DPI Canvas scaling, and `localStorage` persistence for Best Score, Total Bamboo, and audio/language settings.

## Local Development & Build

```bash
npm install
npm run dev
```

To build for static hosting (e.g., GitHub Pages):

```bash
npm run build
```

The production output in `dist/` uses relative paths (`base: './'` in `vite.config.ts`) and requires no backend server.

## How to Publish on GitHub Pages Using an Android Phone

1. **Create a GitHub Repository**:
   - Open Chrome on your Android phone and sign in to [github.com](https://github.com).
   - Tap the **+** icon at the top right and choose **New repository**.
   - Enter a repository name such as `panda-bash`, select **Public**, and tap **Create repository**.
2. **Upload the Built Game Files**:
   - Export/download the built project files (`dist/` contents: `index.html` and the `assets/` folder) onto your phone.
   - In your new GitHub repository page, tap **uploading an existing file** (or **Add file → Upload files**).
   - Select `index.html` and the `assets` files from your phone storage and tap **Commit changes** (make sure `index.html` sits at the root of the repository or inside `/docs`).
   - *Tip*: If uploading the full source repo instead of `dist/`, you can also enable a GitHub Actions workflow (`Deploy static Vite site`) under **Settings → Pages → GitHub Actions**.
3. **Enable GitHub Pages**:
   - Go to your repository's **Settings** tab → **Pages**.
   - Under **Build and deployment → Source**, choose **Deploy from a branch**.
   - Select branch `main` and folder `/ (root)` (or `/docs` if you placed built files there), then tap **Save**.
4. **Get Your Public Game URL**:
   - Wait 1–2 minutes and refresh the **Settings → Pages** page.
   - Your live URL will appear at the top: `https://<your-username>.github.io/panda-bash/`.
5. **Test the Public Version**:
   - Open the URL in Android Chrome.
   - Tap **Play** to unlock browser audio, test swipe left/right/up/down, pause, and refresh the page to confirm your Best Score and settings persist.

## License

Apache-2.0
