import { useCallback, useEffect, useRef, useState } from 'react';
import {
  CountdownOverlay,
  GameOverModal,
  GameplayHud,
  HowToPlayModal,
  LoadingScreen,
  PauseModal,
  SettingsModal,
  StartMenu,
} from './components/Screens';
import { audioEngine } from './game/audio';
import { PandaGameEngine } from './game/engine';
import { TRANSLATIONS } from './game/i18n';
import {
  loadSaveData,
  recordRunStorage,
  updateSettingsStorage,
} from './game/storage';
import {
  GameSettings,
  GameState,
  HudSnapshot,
  ObstacleType,
  RunSummary,
  SaveData,
} from './game/types';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<PandaGameEngine | null>(null);

  const [saveData, setSaveData] = useState<SaveData>(() => loadSaveData());
  const saveDataRef = useRef<SaveData>(saveData);
  saveDataRef.current = saveData;

  const [gameState, setGameState] = useState<GameState>('LOADING');
  const [loadProgress, setLoadProgress] = useState(15);
  const [showSettings, setShowSettings] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);

  const [hud, setHud] = useState<HudSnapshot>({
    score: 0,
    bamboo: 0,
    distance: 0,
    speedMultiplier: 1.0,
    combo: 0,
    countdownValue: 3,
    isNewRecord: false,
  });

  const [runSummary, setRunSummary] = useState<RunSummary | null>(null);

  const t = TRANSLATIONS[saveData.language];

  // Sync audio engine with initial and updated settings
  useEffect(() => {
    audioEngine.applySettings(saveData);
  }, [
    saveData.musicEnabled,
    saveData.sfxEnabled,
    saveData.musicVolume,
    saveData.sfxVolume,
  ]);

  // Mount isolated 60fps Canvas Game Engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new PandaGameEngine(canvas, {
      onHudUpdate: (snapshot) => setHud(snapshot),
      onStateChange: (nextState) => setGameState(nextState),
      onGameOver: ({ score, bamboo, distance, hitObstacle }) => {
        const currentSave = saveDataRef.current;
        const { next, isNewRecord } = recordRunStorage(
          currentSave,
          score,
          bamboo,
          distance
        );
        setSaveData(next);
        setRunSummary({
          score,
          bamboo,
          distance,
          bestScore: next.bestScore,
          totalBamboo: next.totalBamboo,
          isNewRecord,
          hitObstacle: hitObstacle as ObstacleType | null,
        });
      },
    });

    engine.setBestScore(saveDataRef.current.bestScore);
    engineRef.current = engine;
    engine.startLoop();

    // Snappy loading progress -> Start Menu
    let prog = 20;
    const loadTimer = window.setInterval(() => {
      prog += 25;
      setLoadProgress(Math.min(100, prog));
      if (prog >= 100) {
        window.clearInterval(loadTimer);
        engine.goToMenu();
      }
    }, 110);

    window.addEventListener('resize', engine.handleResize);

    return () => {
      window.clearInterval(loadTimer);
      window.removeEventListener('resize', engine.handleResize);
      engine.stopLoop();
      audioEngine.dispose();
    };
  }, []);

  // Touch swipe listeners on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const engine = engineRef.current;
    if (!canvas || !engine) return;

    canvas.addEventListener('touchstart', engine.onTouchStart, { passive: true });
    canvas.addEventListener('touchmove', engine.onTouchMove, { passive: true });
    canvas.addEventListener('touchend', engine.onTouchEnd, { passive: true });
    canvas.addEventListener('touchcancel', engine.onTouchEnd, { passive: true });

    return () => {
      canvas.removeEventListener('touchstart', engine.onTouchStart);
      canvas.removeEventListener('touchmove', engine.onTouchMove);
      canvas.removeEventListener('touchend', engine.onTouchEnd);
      canvas.removeEventListener('touchcancel', engine.onTouchEnd);
    };
  }, []);

  const handlePlay = useCallback(() => {
    audioEngine.unlock();
    audioEngine.playButtonClick();
    setRunSummary(null);
    setShowSettings(false);
    setShowHowToPlay(false);
    engineRef.current?.startNewRun(saveDataRef.current.bestScore);
  }, []);

  const handlePause = useCallback(() => {
    engineRef.current?.pause();
  }, []);

  const handleResume = useCallback(() => {
    audioEngine.playButtonClick();
    engineRef.current?.resume();
  }, []);

  const handleMainMenu = useCallback(() => {
    audioEngine.playButtonClick();
    setRunSummary(null);
    engineRef.current?.goToMenu();
  }, []);

  const handleUpdateSettings = useCallback((patch: Partial<GameSettings>) => {
    audioEngine.unlock();
    audioEngine.playButtonClick();
    setSaveData((prev) => updateSettingsStorage(prev, patch));
  }, []);

  const handleToggleMute = useCallback(() => {
    audioEngine.unlock();
    setSaveData((prev) => {
      const currentlyMuted = !prev.musicEnabled && !prev.sfxEnabled;
      const next = updateSettingsStorage(prev, {
        musicEnabled: currentlyMuted ? true : false,
        sfxEnabled: currentlyMuted ? true : false,
      });
      if (currentlyMuted) {
        audioEngine.applySettings(next);
        audioEngine.playButtonClick();
      }
      return next;
    });
  }, []);

  // Keyboard Controls + Prevent Unwanted Browser Scrolling + Window Blur/Visibility Safety
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      const key = e.key.toLowerCase();

      if (
        code === 'Space' ||
        code === 'ArrowUp' ||
        code === 'ArrowDown' ||
        code === 'ArrowLeft' ||
        code === 'ArrowRight'
      ) {
        e.preventDefault();
      }

      if (showSettings || showHowToPlay) {
        if (code === 'Escape') {
          setShowSettings(false);
          setShowHowToPlay(false);
        }
        return;
      }

      const engine = engineRef.current;
      if (!engine) return;
      const state = engine.getState();

      if (state === 'MENU') {
        if (code === 'Enter' || code === 'Space') {
          handlePlay();
        }
        return;
      }

      if (state === 'PLAYING') {
        if (code === 'ArrowLeft' || key === 'a') {
          engine.moveLeft();
        } else if (code === 'ArrowRight' || key === 'd') {
          engine.moveRight();
        } else if (code === 'ArrowUp' || key === 'w' || code === 'Space') {
          engine.triggerJump();
        } else if (code === 'ArrowDown' || key === 's') {
          engine.triggerSlide();
        } else if (code === 'Escape' || key === 'p') {
          engine.pause();
        }
        return;
      }

      if (state === 'PAUSED') {
        if (code === 'Escape' || key === 'p' || code === 'Space') {
          handleResume();
        }
        return;
      }

      if (state === 'GAME_OVER') {
        if (code === 'Enter' || code === 'Space') {
          handlePlay();
        }
      }
    };

    const onBlur = () => {
      if (engineRef.current?.getState() === 'PLAYING') {
        engineRef.current.pause();
      }
    };

    const onVisibilityChange = () => {
      if (document.hidden) {
        audioEngine.suspendOnHide();
        if (engineRef.current?.getState() === 'PLAYING') {
          engineRef.current.pause();
        }
      } else {
        audioEngine.resumeOnShow();
      }
    };

    window.addEventListener('keydown', onKeyDown, { passive: false });
    window.addEventListener('blur', onBlur);
    document.addEventListener('visibilitychange', onVisibilityChange);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [showSettings, showHowToPlay, handlePlay, handleResume]);

  // First click anywhere on Start Menu unlocks browser AudioContext cleanly
  const handleUnlockAudio = () => {
    audioEngine.unlock();
    if (gameState === 'MENU') {
      audioEngine.setMusicTrack('menu');
    }
  };

  return (
    <main
      onPointerDown={handleUnlockAudio}
      className="relative w-full h-[100dvh] overflow-hidden bg-[#0B2418] touch-none select-none"
    >
      {/* Isolated 60fps HTML5 Canvas */}
      <canvas
        ref={canvasRef}
        className="block w-full h-full touch-none"
        aria-label="PANDA BAMBOO 2D Endless Runner Game Canvas"
      />

      {/* A. Loading Screen */}
      {gameState === 'LOADING' && (
        <LoadingScreen progress={loadProgress} t={t} />
      )}

      {/* B. Start Menu */}
      {gameState === 'MENU' && (
        <StartMenu
          saveData={saveData}
          t={t}
          onPlay={handlePlay}
          onOpenSettings={() => {
            audioEngine.playButtonClick();
            setShowSettings(true);
          }}
          onOpenHowToPlay={() => {
            audioEngine.playButtonClick();
            setShowHowToPlay(true);
          }}
          onToggleLanguage={() =>
            handleUpdateSettings({
              language: saveData.language === 'en' ? 'bn' : 'en',
            })
          }
          onToggleMute={handleToggleMute}
        />
      )}

      {/* C. Gameplay HUD */}
      {(gameState === 'PLAYING' || gameState === 'COUNTDOWN') && (
        <GameplayHud
          hud={hud}
          t={t}
          onScreenControls={saveData.onScreenControls && gameState === 'PLAYING'}
          onPause={handlePause}
          onLeft={() => engineRef.current?.moveLeft()}
          onRight={() => engineRef.current?.moveRight()}
          onJump={() => engineRef.current?.triggerJump()}
          onSlide={() => engineRef.current?.triggerSlide()}
        />
      )}

      {/* D. Countdown Overlay */}
      {gameState === 'COUNTDOWN' && (
        <CountdownOverlay value={hud.countdownValue} t={t} />
      )}

      {/* E. Pause Modal */}
      {gameState === 'PAUSED' && !showSettings && (
        <PauseModal
          t={t}
          settings={saveData}
          onResume={handleResume}
          onRestart={handlePlay}
          onOpenSettings={() => {
            audioEngine.playButtonClick();
            setShowSettings(true);
          }}
          onMainMenu={handleMainMenu}
          onUpdateSettings={handleUpdateSettings}
        />
      )}

      {/* F. Game Over Modal */}
      {gameState === 'GAME_OVER' && runSummary && (
        <GameOverModal
          summary={runSummary}
          t={t}
          onRestart={handlePlay}
          onMainMenu={handleMainMenu}
        />
      )}

      {/* G. Settings Modal */}
      {showSettings && (
        <SettingsModal
          settings={saveData}
          t={t}
          onUpdate={handleUpdateSettings}
          onClose={() => {
            audioEngine.playButtonClick();
            setShowSettings(false);
          }}
        />
      )}

      {/* H. How to Play Modal */}
      {showHowToPlay && (
        <HowToPlayModal
          t={t}
          onClose={() => {
            audioEngine.playButtonClick();
            setShowHowToPlay(false);
          }}
        />
      )}
    </main>
  );
}
