import React from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  BookOpen,
  Home,
  Pause,
  Play,
  RotateCcw,
  Settings,
  Trophy,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import forestBackdropUrl from '../assets/images/bamboo_forest_backdrop_1795458229623.jpg';
import { Translations } from '../game/i18n';
import { GameSettings, HudSnapshot, Language, RunSummary, SaveData } from '../game/types';
import {
  PandaAppIcon,
  PandaMascotShowcase,
  PandaTitleLockup,
} from './PandaLogo';

/* ==================== A. LOADING SCREEN ==================== */
export const LoadingScreen: React.FC<{ progress: number; t: Translations }> = ({
  progress,
  t,
}) => (
  <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#0B2418] px-6">
    <img
      src={forestBackdropUrl}
      alt="Bamboo forest background"
      referrerPolicy="no-referrer"
      className="absolute inset-0 h-full w-full object-cover opacity-40"
    />
    <div className="absolute inset-0 bg-gradient-to-b from-[#071910]/80 via-[#0B2418]/55 to-[#071910]/92" />

    <div className="relative z-10 flex flex-col items-center gap-5 max-w-sm w-full">
      <div className="animate-float-slow">
        <PandaMascotShowcase className="w-40 h-40 sm:w-44 sm:h-44" />
      </div>
      <PandaTitleLockup compact />
      <div className="w-full max-w-[260px] space-y-2 mt-1">
        <div className="h-3.5 w-full overflow-hidden rounded-full bg-[#0F3522] border-2 border-[#4ADE80]/40 p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#22C55E] via-[#4ADE80] to-[#FACC15] transition-[width] duration-150"
            style={{ width: `${Math.min(100, Math.max(8, progress))}%` }}
          />
        </div>
        <p className="text-center text-xs sm:text-sm font-semibold text-[#DCFCE7]">
          {t.loading}
        </p>
      </div>
    </div>
  </div>
);

/* ==================== B. START MENU ==================== */
interface StartMenuProps {
  saveData: SaveData;
  t: Translations;
  onPlay: () => void;
  onOpenSettings: () => void;
  onOpenHowToPlay: () => void;
  onToggleLanguage: () => void;
  onToggleMute: () => void;
}

export const StartMenu: React.FC<StartMenuProps> = ({
  saveData,
  t,
  onPlay,
  onOpenSettings,
  onOpenHowToPlay,
  onToggleLanguage,
  onToggleMute,
}) => {
  const isMuted = !saveData.musicEnabled && !saveData.sfxEnabled;

  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-between p-4 sm:p-6 pointer-events-none">
      {/* Top Bar: App Icon + Persistent Stats + Sound & Language */}
      <div className="flex items-start justify-between gap-3 w-full">
        <div className="pointer-events-auto flex items-center gap-2.5 bg-[#0A2618]/85 border border-[#4ADE80]/25 rounded-2xl px-3 py-2 shadow-lg">
          <PandaAppIcon size="sm" />
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-xs sm:text-sm text-[#ECFDF5]">
            <div className="flex items-center gap-1">
              <Trophy className="w-4 h-4 text-[#FACC15] shrink-0" />
              <span className="text-[#BBF7D0]/85">{t.bestScore}:</span>
              <span className="font-display font-bold tabular-nums text-[#FACC15]">
                {saveData.bestScore.toLocaleString()}
              </span>
            </div>
            <span className="text-white/25" aria-hidden="true">·</span>
            <div className="flex items-center gap-1">
              <span className="text-[#BBF7D0]/85">{t.totalBamboo}:</span>
              <span className="font-display font-bold tabular-nums text-[#86EFAC]">
                {saveData.totalBamboo.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleLanguage}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-[#14442A]/90 hover:bg-[#166534] border border-[#4ADE80]/30 text-xs sm:text-sm font-semibold text-[#F7FAF5] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#FACC15]"
          >
            {saveData.language === 'en' ? 'বাংলা' : 'English'}
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[#14442A]/90 hover:bg-[#166534] border border-[#4ADE80]/30 text-[#F7FAF5] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#FACC15]"
          >
            {isMuted ? (
              <VolumeX className="w-5 h-5 text-rose-300" />
            ) : (
              <Volume2 className="w-5 h-5 text-[#86EFAC]" />
            )}
          </button>
        </div>
      </div>

      {/* Center Mascot Showcase + Official PANDA BAMBOO Logo */}
      <div className="flex flex-col items-center justify-center gap-3 sm:gap-4 my-auto py-2">
        <PandaTitleLockup />
        <div className="animate-float-slow">
          <PandaMascotShowcase className="w-40 h-40 sm:w-52 sm:h-52" />
        </div>
      </div>

      {/* Bottom Bamboo-Themed Action Buttons */}
      <div className="flex flex-col items-center gap-2.5 pb-1 sm:pb-3">
        <div className="pointer-events-auto flex flex-col sm:flex-row items-center gap-2.5 w-full max-w-md justify-center">
          <button
            type="button"
            onClick={onPlay}
            className="w-full sm:w-auto min-w-[210px] min-h-[54px] px-8 py-3 rounded-2xl bg-gradient-to-b from-[#4ADE80] via-[#22C55E] to-[#15803D] hover:from-[#86EFAC] hover:to-[#16A34A] active:scale-[0.98] border-2 border-[#BBF7D0]/50 text-[#052E16] font-display font-black text-lg sm:text-xl tracking-wide shadow-[0_6px_0_#0D4422,0_12px_24px_rgba(0,0,0,0.45)] transition-all flex items-center justify-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#FACC15]"
          >
            <Play className="w-6 h-6 fill-current" />
            <span>{t.play}</span>
          </button>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-center">
            <button
              type="button"
              onClick={onOpenHowToPlay}
              className="flex-1 sm:flex-initial min-h-[48px] px-4 py-2.5 rounded-xl bg-[#0F3822]/92 hover:bg-[#164E30] border border-[#4ADE80]/30 text-[#ECFDF5] font-semibold text-sm flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-[0_4px_0_#071E12] focus-visible:outline-2 focus-visible:outline-[#FACC15]"
            >
              <BookOpen className="w-4 h-4 text-[#FACC15]" />
              <span>{t.howToPlay}</span>
            </button>

            <button
              type="button"
              onClick={onOpenSettings}
              className="flex-1 sm:flex-initial min-h-[48px] px-4 py-2.5 rounded-xl bg-[#0F3822]/92 hover:bg-[#164E30] border border-[#4ADE80]/30 text-[#ECFDF5] font-semibold text-sm flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-[0_4px_0_#071E12] focus-visible:outline-2 focus-visible:outline-[#FACC15]"
            >
              <Settings className="w-4 h-4 text-[#86EFAC]" />
              <span>{t.settings}</span>
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-[#ECFDF5]/90 bg-[#071910]/70 px-3 py-1 rounded-lg max-w-xl">
          <span className="hidden sm:inline">{t.controlHintDesktop}</span>
          <span className="sm:hidden">{t.controlHintMobile}</span>
        </p>
      </div>
    </div>
  );
};

/* ==================== C. GAMEPLAY HUD ==================== */
interface GameplayHudProps {
  hud: HudSnapshot;
  t: Translations;
  onScreenControls: boolean;
  onPause: () => void;
  onLeft: () => void;
  onRight: () => void;
  onJump: () => void;
  onSlide: () => void;
}

export const GameplayHud: React.FC<GameplayHudProps> = ({
  hud,
  t,
  onScreenControls,
  onPause,
  onLeft,
  onRight,
  onJump,
  onSlide,
}) => (
  <div className="absolute inset-0 z-20 flex flex-col justify-between p-3 sm:p-5 pointer-events-none">
    <div className="flex items-start justify-between gap-2 w-full">
      <div className="bg-[#092215]/82 border border-[#4ADE80]/25 rounded-2xl px-3.5 py-2 shadow-md">
        <div className="flex items-baseline gap-3 sm:gap-4">
          <div>
            <div className="text-[11px] font-medium text-[#BBF7D0]/80 leading-none">
              {t.score}
            </div>
            <div className="font-display font-extrabold text-xl sm:text-2xl text-[#FACC15] tabular-nums leading-tight">
              {hud.score.toLocaleString()}
            </div>
          </div>

          <div className="h-7 w-px bg-[#4ADE80]/25 self-center" aria-hidden="true" />

          <div>
            <div className="text-[11px] font-medium text-[#BBF7D0]/80 leading-none">
              {t.bamboo}
            </div>
            <div className="font-display font-bold text-lg sm:text-xl text-[#86EFAC] tabular-nums leading-tight">
              {hud.bamboo}
            </div>
          </div>

          <div className="h-7 w-px bg-[#4ADE80]/25 self-center" aria-hidden="true" />

          <div>
            <div className="text-[11px] font-medium text-[#BBF7D0]/80 leading-none">
              {t.distance}
            </div>
            <div className="font-display font-bold text-base sm:text-lg text-[#F7FAF5] tabular-nums leading-tight">
              {hud.distance}m
            </div>
          </div>

          <div className="hidden sm:block h-7 w-px bg-[#4ADE80]/25 self-center" aria-hidden="true" />

          <div className="hidden sm:block">
            <div className="text-[11px] font-medium text-[#BBF7D0]/80 leading-none">
              {t.speed}
            </div>
            <div className="font-display font-bold text-base text-[#FDE68A] tabular-nums leading-tight">
              {hud.speedMultiplier.toFixed(1)}x
            </div>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={onPause}
        aria-label={t.pause}
        className="pointer-events-auto min-h-[44px] min-w-[44px] px-3.5 py-2 rounded-xl bg-[#14442A]/90 hover:bg-[#166534] border border-[#4ADE80]/35 text-[#F7FAF5] flex items-center justify-center gap-1.5 font-semibold text-xs sm:text-sm transition-colors cursor-pointer shadow-[0_3px_0_#071E12] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#FACC15]"
      >
        <Pause className="w-4 h-4 text-[#FACC15]" />
        <span className="hidden sm:inline">{t.pause}</span>
      </button>
    </div>

    {onScreenControls && (
      <div className="flex items-end justify-between gap-4 pb-2 pointer-events-none">
        <div className="flex items-center gap-2.5 pointer-events-auto">
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              onLeft();
            }}
            aria-label={t.leftBtn}
            className="w-14 h-14 rounded-2xl bg-[#0F3822]/85 active:bg-[#22C55E] border border-[#4ADE80]/35 text-white flex items-center justify-center shadow-lg"
          >
            <ArrowLeft className="w-7 h-7" />
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              onRight();
            }}
            aria-label={t.rightBtn}
            className="w-14 h-14 rounded-2xl bg-[#0F3822]/85 active:bg-[#22C55E] border border-[#4ADE80]/35 text-white flex items-center justify-center shadow-lg"
          >
            <ArrowRight className="w-7 h-7" />
          </button>
        </div>

        <div className="flex items-center gap-2.5 pointer-events-auto">
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              onSlide();
            }}
            aria-label={t.slideBtn}
            className="w-14 h-14 rounded-2xl bg-[#0F3822]/85 active:bg-[#F59E0B] border border-[#4ADE80]/35 text-white flex items-center justify-center shadow-lg"
          >
            <ArrowDown className="w-7 h-7" />
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              onJump();
            }}
            aria-label={t.jumpBtn}
            className="w-14 h-14 rounded-2xl bg-[#22C55E]/90 active:bg-[#4ADE80] border border-[#BBF7D0]/45 text-[#052E16] flex items-center justify-center shadow-lg"
          >
            <ArrowUp className="w-7 h-7 stroke-[2.6]" />
          </button>
        </div>
      </div>
    )}
  </div>
);

/* ==================== D. COUNTDOWN OVERLAY ==================== */
export const CountdownOverlay: React.FC<{ value: number; t: Translations }> = ({
  value,
  t,
}) => {
  const label = value > 0 ? String(value) : t.countdownGo;
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none">
      <div
        key={label}
        className="animate-count-pulse font-display font-black text-7xl sm:text-8xl text-[#FACC15] drop-shadow-[0_6px_0_#071910] tracking-tight"
      >
        {label}
      </div>
    </div>
  );
};

/* ==================== E. PAUSE MODAL ==================== */
interface PauseModalProps {
  t: Translations;
  settings: GameSettings;
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onMainMenu: () => void;
  onUpdateSettings: (patch: Partial<GameSettings>) => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  t,
  settings,
  onResume,
  onRestart,
  onOpenSettings,
  onMainMenu,
  onUpdateSettings,
}) => (
  <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#06150D]/82 p-4">
    <div className="animate-pop-in w-full max-w-sm rounded-2xl bg-[#0E2B1C] border-2 border-[#4ADE80]/30 p-6 shadow-2xl space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <PandaAppIcon size="sm" />
          <h2 className="font-display font-extrabold text-2xl text-[#FACC15]">
            {t.paused}
          </h2>
        </div>
        <button
          type="button"
          onClick={onResume}
          aria-label={t.resume}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 text-[#ECFDF5] cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => onUpdateSettings({ musicEnabled: !settings.musicEnabled })}
          className={`min-h-[44px] px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            settings.musicEnabled
              ? 'bg-[#16A34A]/30 border-[#4ADE80]/55 text-[#DCFCE7]'
              : 'bg-white/5 border-white/10 text-white/60'
          }`}
        >
          {settings.musicEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          <span>{t.music}</span>
        </button>

        <button
          type="button"
          onClick={() => onUpdateSettings({ sfxEnabled: !settings.sfxEnabled })}
          className={`min-h-[44px] px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            settings.sfxEnabled
              ? 'bg-[#16A34A]/30 border-[#4ADE80]/55 text-[#DCFCE7]'
              : 'bg-white/5 border-white/10 text-white/60'
          }`}
        >
          {settings.sfxEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          <span>{t.sfx}</span>
        </button>
      </div>

      <div className="flex flex-col gap-2.5">
        <button
          type="button"
          onClick={onResume}
          className="w-full min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-b from-[#4ADE80] to-[#15803D] hover:from-[#86EFAC] hover:to-[#16A34A] text-[#052E16] font-display font-extrabold text-base flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_0_#0D4422]"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>{t.resume}</span>
        </button>

        <button
          type="button"
          onClick={onRestart}
          className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-[#14442A] hover:bg-[#166534] border border-[#4ADE80]/25 text-[#ECFDF5] font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{t.restart}</span>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-[#14442A] hover:bg-[#166534] border border-[#4ADE80]/25 text-[#ECFDF5] font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
        >
          <Settings className="w-4 h-4 text-[#86EFAC]" />
          <span>{t.soundSettings}</span>
        </button>

        <button
          type="button"
          onClick={onMainMenu}
          className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#BBF7D0]/85 font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>{t.mainMenu}</span>
        </button>
      </div>
    </div>
  </div>
);

/* ==================== F. GAME OVER MODAL ==================== */
interface GameOverModalProps {
  summary: RunSummary;
  t: Translations;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  summary,
  t,
  onRestart,
  onMainMenu,
}) => {
  const reaction =
    (summary.hitObstacle && t.funnyReactions[summary.hitObstacle]) ||
    t.funnyReactions.default;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#06150D]/82 p-4">
      <div className="animate-pop-in w-full max-w-md rounded-2xl bg-[#0E2B1C] border-2 border-[#4ADE80]/30 p-6 shadow-2xl space-y-5">
        <div className="flex flex-col items-center text-center space-y-2.5">
          <PandaAppIcon size="lg" />
          {summary.isNewRecord && (
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-[#FACC15]">
              <Trophy className="w-4 h-4" />
              <span>{t.newRecord}</span>
            </div>
          )}
          <h2 className="font-display font-black text-3xl text-white">
            {t.gameOver}
          </h2>
          <p className="text-sm text-[#BBF7D0]/90 leading-snug">{reaction}</p>
        </div>

        <div className="grid grid-cols-2 gap-x-4 gap-y-4 border-y border-[#4ADE80]/20 py-4">
          <div>
            <div className="text-xs text-[#BBF7D0]/75">{t.finalScore}</div>
            <div className="font-display font-extrabold text-3xl text-[#FACC15] tabular-nums">
              {summary.score.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="text-xs text-[#BBF7D0]/75">{t.personalBest}</div>
            <div className="font-display font-extrabold text-2xl text-white tabular-nums">
              {summary.bestScore.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="text-xs text-[#BBF7D0]/75">{t.bambooCollected}</div>
            <div className="font-display font-bold text-xl text-[#86EFAC] tabular-nums">
              {summary.bamboo}
            </div>
          </div>

          <div>
            <div className="text-xs text-[#BBF7D0]/75">{t.distanceTravelled}</div>
            <div className="font-display font-bold text-xl text-[#ECFDF5] tabular-nums">
              {summary.distance}m
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            type="button"
            onClick={onRestart}
            className="flex-1 min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-b from-[#4ADE80] to-[#15803D] hover:from-[#86EFAC] hover:to-[#16A34A] text-[#052E16] font-display font-extrabold text-base flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_0_#0D4422] whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-5 h-5" />
            <span>{t.playAgain}</span>
          </button>

          <button
            type="button"
            onClick={onMainMenu}
            className="sm:w-auto min-h-[48px] px-5 py-2.5 rounded-xl bg-[#14442A] hover:bg-[#166534] border border-[#4ADE80]/25 text-[#ECFDF5] font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Home className="w-4 h-4" />
            <span>{t.home}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

/* ==================== G. SETTINGS MODAL ==================== */
interface SettingsModalProps {
  settings: GameSettings;
  t: Translations;
  onUpdate: (patch: Partial<GameSettings>) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  t,
  onUpdate,
  onClose,
}) => (
  <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#06150D]/85 p-4">
    <div className="animate-pop-in w-full max-w-md max-h-[90dvh] overflow-y-auto rounded-2xl bg-[#0E2B1C] border-2 border-[#4ADE80]/30 p-6 shadow-2xl space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PandaAppIcon size="sm" />
          <h2 className="font-display font-extrabold text-2xl text-white">
            {t.settings}
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label={t.close}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-[#ECFDF5]">{t.music}</span>
            <button
              type="button"
              onClick={() => onUpdate({ musicEnabled: !settings.musicEnabled })}
              className={`min-h-[40px] px-4 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                settings.musicEnabled
                  ? 'bg-[#22C55E] text-[#052E16]'
                  : 'bg-white/10 text-white/70'
              }`}
            >
              {settings.musicEnabled ? t.on : t.off}
            </button>
          </div>
          <label className="block">
            <span className="text-xs text-[#BBF7D0]/70">
              {t.musicVolume}: {Math.round(settings.musicVolume * 100)}%
            </span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.musicVolume}
              onChange={(e) => onUpdate({ musicVolume: parseFloat(e.target.value) })}
              className="w-full accent-[#22C55E] mt-1 h-2 cursor-pointer"
            />
          </label>
        </div>

        <div className="h-px bg-[#4ADE80]/15" />

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-[#ECFDF5]">{t.sfx}</span>
            <button
              type="button"
              onClick={() => onUpdate({ sfxEnabled: !settings.sfxEnabled })}
              className={`min-h-[40px] px-4 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                settings.sfxEnabled
                  ? 'bg-[#22C55E] text-[#052E16]'
                  : 'bg-white/10 text-white/70'
              }`}
            >
              {settings.sfxEnabled ? t.on : t.off}
            </button>
          </div>
          <label className="block">
            <span className="text-xs text-[#BBF7D0]/70">
              {t.sfxVolume}: {Math.round(settings.sfxVolume * 100)}%
            </span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.sfxVolume}
              onChange={(e) => onUpdate({ sfxVolume: parseFloat(e.target.value) })}
              className="w-full accent-[#FACC15] mt-1 h-2 cursor-pointer"
            />
          </label>
        </div>

        <div className="h-px bg-[#4ADE80]/15" />

        <div className="flex items-center justify-between gap-3">
          <span className="text-sm font-semibold text-[#ECFDF5]">{t.language}</span>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#071910]">
            {(['en', 'bn'] as Language[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => onUpdate({ language: lang })}
                className={`min-h-[38px] px-3.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  settings.language === lang
                    ? 'bg-[#22C55E] text-[#052E16]'
                    : 'text-[#BBF7D0]/80 hover:text-white'
                }`}
              >
                {lang === 'en' ? 'English' : 'বাংলা'}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between gap-3">
          <span className="text-sm font-semibold text-[#ECFDF5]">
            {t.onScreenButtons}
          </span>
          <button
            type="button"
            onClick={() =>
              onUpdate({ onScreenControls: !settings.onScreenControls })
            }
            className={`min-h-[40px] px-4 rounded-lg text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              settings.onScreenControls
                ? 'bg-[#22C55E] text-[#052E16]'
                : 'bg-white/10 text-white/70'
            }`}
          >
            {settings.onScreenControls ? t.on : t.off}
          </button>
        </div>

        <div className="h-px bg-[#4ADE80]/15" />

        <div className="space-y-1.5 text-xs text-[#BBF7D0]/85">
          <div className="font-bold text-[#FACC15] text-sm">{t.controlsTitle}</div>
          <p>{t.controlsMove}</p>
          <p>{t.controlsJump}</p>
          <p>{t.controlsSlide}</p>
          <p>{t.controlsPause}</p>
        </div>
      </div>

      <button
        type="button"
        onClick={onClose}
        className="w-full min-h-[48px] rounded-xl bg-gradient-to-b from-[#4ADE80] to-[#15803D] text-[#052E16] font-display font-extrabold text-base cursor-pointer shadow-[0_4px_0_#0D4422]"
      >
        {t.close}
      </button>
    </div>
  </div>
);

/* ==================== H. HOW TO PLAY MODAL ==================== */
export const HowToPlayModal: React.FC<{
  t: Translations;
  onClose: () => void;
}> = ({ t, onClose }) => (
  <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#06150D]/85 p-4">
    <div className="animate-pop-in w-full max-w-md max-h-[90dvh] overflow-y-auto rounded-2xl bg-[#0E2B1C] border-2 border-[#4ADE80]/30 p-6 shadow-2xl space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PandaAppIcon size="sm" />
          <h2 className="font-display font-extrabold text-2xl text-[#FACC15]">
            {t.howToPlay}
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label={t.close}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-3 text-sm text-[#ECFDF5]/95">
        <div className="font-bold text-[#86EFAC]">{t.controlsTitle}</div>
        <ul className="space-y-1.5 text-xs sm:text-sm text-[#BBF7D0]/90">
          <li>• {t.controlsMove}</li>
          <li>• {t.controlsJump}</li>
          <li>• {t.controlsSlide}</li>
          <li>• {t.controlsPause}</li>
        </ul>

        <div className="h-px bg-[#4ADE80]/15 my-2" />

        <div className="font-bold text-[#FACC15]">{t.obstaclesTitle}</div>
        <ul className="space-y-1.5 text-xs sm:text-sm text-[#BBF7D0]/90">
          <li>• {t.tipJump}</li>
          <li>• {t.tipSlide}</li>
          <li>• {t.tipSwitch}</li>
          <li>• {t.tipBamboo}</li>
        </ul>
      </div>

      <button
        type="button"
        onClick={onClose}
        className="w-full min-h-[48px] rounded-xl bg-gradient-to-b from-[#4ADE80] to-[#15803D] text-[#052E16] font-display font-extrabold text-base cursor-pointer shadow-[0_4px_0_#0D4422]"
      >
        {t.back}
      </button>
    </div>
  </div>
);
