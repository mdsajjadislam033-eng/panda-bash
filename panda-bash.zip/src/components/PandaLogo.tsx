import React from 'react';

export const PANDA_MASCOT_URL =
  './assets/aistudio/file_0000000097b88211ac13361eefffe4f0_c2fcc832.png';

/**
 * Square game app icon framing the official uploaded Panda character's face & green scarf.
 */
export const PandaAppIcon: React.FC<{
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-11 h-11 rounded-xl border-2',
    md: 'w-16 h-16 rounded-2xl border-[3px]',
    lg: 'w-24 h-24 rounded-[22px] border-[3.5px]',
    xl: 'w-32 h-32 rounded-[28px] border-4',
  }[size];

  return (
    <div
      className={`relative overflow-hidden shrink-0 border-[#86EFAC] bg-[#14532D] shadow-[0_8px_20px_rgba(0,0,0,0.45),inset_0_2px_0_rgba(255,255,255,0.35)] ${sizeClasses} ${className}`}
    >
      <img
        src={PANDA_MASCOT_URL}
        alt="PANDA BAMBOO Mascot"
        referrerPolicy="no-referrer"
        className="w-full h-full object-cover object-[56%_28%] scale-[1.55]"
      />
      <div
        className="pointer-events-none absolute inset-0 rounded-[inherit] ring-1 ring-inset ring-white/25"
        aria-hidden="true"
      />
    </div>
  );
};

/**
 * Full mascot illustration showcase preserving the exact uploaded Panda character.
 */
export const PandaMascotShowcase: React.FC<{
  className?: string;
}> = ({ className = 'w-44 h-44 sm:w-52 sm:h-52' }) => (
  <div
    className={`relative overflow-hidden rounded-[28px] border-4 border-[#4ADE80] bg-[#0F3D22] shadow-[0_14px_32px_rgba(0,0,0,0.5),0_0_0_4px_rgba(11,36,24,0.65)] ${className}`}
  >
    <img
      src={PANDA_MASCOT_URL}
      alt="PANDA BAMBOO Official Mascot"
      referrerPolicy="no-referrer"
      className="w-full h-full object-cover object-center"
    />
    <div
      className="pointer-events-none absolute inset-0 rounded-[24px] ring-1 ring-inset ring-white/25"
      aria-hidden="true"
    />
  </div>
);

/**
 * Official PANDA BAMBOO Game Logo lockup featuring the uploaded Panda App Icon.
 */
export const PandaTitleLockup: React.FC<{ compact?: boolean }> = ({
  compact = false,
}) => (
  <div className="flex flex-col items-center text-center select-none">
    <div className="flex items-center gap-3 sm:gap-4">
      {!compact && <PandaAppIcon size="md" className="hidden sm:block" />}
      <svg
        viewBox="0 0 380 86"
        className={
          compact
            ? 'w-56 sm:w-64 h-auto'
            : 'w-72 sm:w-[340px] h-auto drop-shadow-[0_6px_16px_rgba(0,0,0,0.5)]'
        }
        role="img"
        aria-label="PANDA BAMBOO"
      >
        <defs>
          <linearGradient id="pandaWordGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="55%" stopColor="#FEF08A" />
            <stop offset="100%" stopColor="#FACC15" />
          </linearGradient>
          <linearGradient id="bambooWordGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#BBF7D0" />
            <stop offset="45%" stopColor="#4ADE80" />
            <stop offset="100%" stopColor="#16A34A" />
          </linearGradient>
        </defs>

        {/* Subtle bamboo stalk underline accent */}
        <rect
          x="34"
          y="72"
          width="312"
          height="6"
          rx="3"
          fill="#15803D"
          stroke="#052E16"
          strokeWidth="2"
        />
        <rect x="128" y="71" width="4" height="8" rx="1.5" fill="#86EFAC" />
        <rect x="248" y="71" width="4" height="8" rx="1.5" fill="#86EFAC" />

        {/* Outline stroke for crisp arcade legibility */}
        <text
          x="190"
          y="36"
          textAnchor="middle"
          fontFamily="Outfit, system-ui, sans-serif"
          fontWeight="900"
          fontSize="38"
          letterSpacing="2"
          stroke="#052E16"
          strokeWidth="9"
          strokeLinejoin="round"
          fill="#052E16"
        >
          PANDA
        </text>
        <text
          x="190"
          y="36"
          textAnchor="middle"
          fontFamily="Outfit, system-ui, sans-serif"
          fontWeight="900"
          fontSize="38"
          letterSpacing="2"
          fill="url(#pandaWordGrad)"
        >
          PANDA
        </text>

        <text
          x="190"
          y="67"
          textAnchor="middle"
          fontFamily="Outfit, system-ui, sans-serif"
          fontWeight="900"
          fontSize="35"
          letterSpacing="2.5"
          stroke="#052E16"
          strokeWidth="9"
          strokeLinejoin="round"
          fill="#052E16"
        >
          BAMBOO
        </text>
        <text
          x="190"
          y="67"
          textAnchor="middle"
          fontFamily="Outfit, system-ui, sans-serif"
          fontWeight="900"
          fontSize="35"
          letterSpacing="2.5"
          fill="url(#bambooWordGrad)"
        >
          BAMBOO
        </text>
      </svg>
    </div>
  </div>
);
