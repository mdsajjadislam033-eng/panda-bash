import { GameSettings, SaveData } from './types';

const STORAGE_KEY = 'panda_bash_save_v1';

export const DEFAULT_SAVE_DATA: SaveData = {
  bestScore: 0,
  totalBamboo: 0,
  bestDistance: 0,
  totalRuns: 0,
  musicEnabled: true,
  sfxEnabled: true,
  musicVolume: 0.55,
  sfxVolume: 0.75,
  language: 'en',
  onScreenControls: false,
};

function clamp01(val: unknown, fallback: number): number {
  if (typeof val !== 'number' || Number.isNaN(val)) return fallback;
  return Math.max(0, Math.min(1, val));
}

function nonNegativeInt(val: unknown, fallback: number): number {
  if (typeof val !== 'number' || Number.isNaN(val) || !Number.isFinite(val)) {
    return fallback;
  }
  return Math.max(0, Math.floor(val));
}

export function loadSaveData(): SaveData {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SAVE_DATA };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      bestScore: nonNegativeInt(parsed.bestScore, 0),
      totalBamboo: nonNegativeInt(parsed.totalBamboo, 0),
      bestDistance: nonNegativeInt(parsed.bestDistance, 0),
      totalRuns: nonNegativeInt(parsed.totalRuns, 0),
      musicEnabled:
        typeof parsed.musicEnabled === 'boolean'
          ? parsed.musicEnabled
          : DEFAULT_SAVE_DATA.musicEnabled,
      sfxEnabled:
        typeof parsed.sfxEnabled === 'boolean'
          ? parsed.sfxEnabled
          : DEFAULT_SAVE_DATA.sfxEnabled,
      musicVolume: clamp01(parsed.musicVolume, DEFAULT_SAVE_DATA.musicVolume),
      sfxVolume: clamp01(parsed.sfxVolume, DEFAULT_SAVE_DATA.sfxVolume),
      language: parsed.language === 'bn' ? 'bn' : 'en',
      onScreenControls:
        typeof parsed.onScreenControls === 'boolean'
          ? parsed.onScreenControls
          : DEFAULT_SAVE_DATA.onScreenControls,
    };
  } catch {
    return { ...DEFAULT_SAVE_DATA };
  }
}

export function persistSaveData(data: SaveData): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota or private-mode security errors safely
  }
}

export function updateSettingsStorage(
  current: SaveData,
  patch: Partial<GameSettings>
): SaveData {
  const next: SaveData = { ...current, ...patch };
  persistSaveData(next);
  return next;
}

export function recordRunStorage(
  current: SaveData,
  runScore: number,
  runBamboo: number,
  runDistance: number
): { next: SaveData; isNewRecord: boolean } {
  const cleanScore = Math.max(0, Math.floor(runScore));
  const cleanBamboo = Math.max(0, Math.floor(runBamboo));
  const cleanDistance = Math.max(0, Math.floor(runDistance));
  const isNewRecord = cleanScore > current.bestScore && cleanScore > 0;
  const next: SaveData = {
    ...current,
    bestScore: Math.max(current.bestScore, cleanScore),
    totalBamboo: current.totalBamboo + cleanBamboo,
    bestDistance: Math.max(current.bestDistance, cleanDistance),
    totalRuns: current.totalRuns + 1,
  };
  persistSaveData(next);
  return { next, isNewRecord };
}
