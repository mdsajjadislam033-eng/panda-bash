import {
  CollectibleEntity,
  FloatingTextEntity,
  GameState,
  ObstacleEntity,
  ParticleEntity,
} from './types';

export interface RenderPlayerState {
  laneX: number; // smoothly interpolated -1 .. +1
  bankAngle: number; // tilt when switching lanes
  jumpY: number; // 0 = ground, >0 = airborne (normalized world units)
  isSliding: boolean;
  slideProgress: number; // 0..1
  runCycle: number;
  squashX: number;
  squashY: number;
  state: GameState;
  hitFlash: number; // 0..1
  dizzyTime: number;
}

export interface RenderWorldState {
  scrollDistance: number;
  speedMultiplier: number;
  shakeX: number;
  shakeY: number;
  time: number;
  player: RenderPlayerState;
  obstacles: ObstacleEntity[];
  collectibles: CollectibleEntity[];
  particles: ParticleEntity[];
  floatingTexts: FloatingTextEntity[];
}

interface ProjectedPoint {
  x: number;
  y: number;
  scale: number;
  trackHalfW: number;
  t: number;
}

export class PandaCanvasRenderer {
  private width = 0;
  private height = 0;
  private dpr = 1;

  public resize(canvas: HTMLCanvasElement): void {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(300, Math.floor(rect.width));
    const h = Math.max(400, Math.floor(rect.height));

    if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
    }
    this.width = w;
    this.height = h;
    this.dpr = dpr;
  }

  public getSize(): { width: number; height: number } {
    return { width: this.width, height: this.height };
  }

  public project(z: number, lane: number, cameraLeanX = 0): ProjectedPoint {
    const W = this.width;
    const H = this.height;
    const isPortrait = H > W;
    const horizonY = H * 0.33;
    const bottomY = H * 0.91;

    const pMin = 1 / (1 + 1.0 * 3.4);
    const p = 1 / (1 + Math.max(-0.18, z) * 3.4);
    const t = (p - pMin) / (1 - pMin);

    const y = horizonY + t * (bottomY - horizonY);
    const scale = Math.max(0.14, 0.22 + t * 0.9);

    const maxHalfW = isPortrait ? W * 0.46 : Math.min(W * 0.34, H * 0.56);
    const trackHalfW = maxHalfW * (0.16 + t * 0.88);

    // Subtle parallax center shift when panda moves left/right
    const centerX = W * 0.5 - cameraLeanX * 14 * t;
    const x = centerX + lane * (trackHalfW * 0.62);

    return { x, y, scale, trackHalfW, t };
  }

  public render(ctx: CanvasRenderingContext2D, world: RenderWorldState): void {
    const W = this.width;
    const H = this.height;
    if (W === 0 || H === 0) return;

    ctx.save();
    ctx.scale(this.dpr, this.dpr);

    // Apply decaying camera shake
    if (world.shakeX !== 0 || world.shakeY !== 0) {
      ctx.translate(world.shakeX, world.shakeY);
    }

    const camLean = world.player.laneX;
    this.drawSkyAndMountains(ctx, W, H, world.time, camLean);
    this.drawGroundAndTrack(ctx, W, H, world.scrollDistance, camLean);
    this.drawSideBambooForest(ctx, W, H, world.scrollDistance, world.time, camLean);

    // Depth-sorted entities (far to near: higher z drawn first)
    const drawItems: Array<{ z: number; kind: 'obs' | 'col'; idx: number }> = [];
    for (let i = 0; i < world.obstacles.length; i++) {
      const o = world.obstacles[i];
      if (o.active && o.z <= 1.05 && o.z >= -0.15) {
        drawItems.push({ z: o.z, kind: 'obs', idx: i });
      }
    }
    for (let i = 0; i < world.collectibles.length; i++) {
      const c = world.collectibles[i];
      if (c.active && !c.collected && c.z <= 1.05 && c.z >= -0.15) {
        drawItems.push({ z: c.z, kind: 'col', idx: i });
      }
    }
    drawItems.sort((a, b) => b.z - a.z);

    const playerZ = 0.08;
    let pandaDrawn = false;

    for (let i = 0; i < drawItems.length; i++) {
      const item = drawItems[i];
      if (!pandaDrawn && item.z < playerZ) {
        this.drawPanda(ctx, world, camLean);
        pandaDrawn = true;
      }
      if (item.kind === 'obs') {
        this.drawObstacle(ctx, world.obstacles[item.idx], world.time, camLean);
      } else {
        this.drawCollectible(ctx, world.collectibles[item.idx], world.time, camLean);
      }
    }

    if (!pandaDrawn) {
      this.drawPanda(ctx, world, camLean);
    }

    // Speed lines at high velocity
    if (world.speedMultiplier > 1.35 && world.player.state === 'PLAYING') {
      this.drawSpeedLines(ctx, W, H, world.speedMultiplier, world.time);
    }

    // Particles & Floating Texts
    this.drawParticles(ctx, world.particles);
    this.drawFloatingTexts(ctx, world.floatingTexts);

    // Subtle hit flash overlay
    if (world.player.hitFlash > 0) {
      ctx.fillStyle = `rgba(255, 240, 220, ${world.player.hitFlash * 0.42})`;
      ctx.fillRect(-20, -20, W + 40, H + 40);
    }

    ctx.restore();
  }

  private drawSkyAndMountains(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    time: number,
    camLean: number
  ): void {
    const horizonY = H * 0.34;
    const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY);
    skyGrad.addColorStop(0, '#7DD3A8');
    skyGrad.addColorStop(0.55, '#C8F0D4');
    skyGrad.addColorStop(1, '#FFF3C4');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(-20, -20, W + 40, horizonY + 30);

    // Warm sun glow
    const sunX = W * 0.52 - camLean * 8;
    const sunY = horizonY * 0.56;
    const sunGlow = ctx.createRadialGradient(sunX, sunY, 8, sunX, sunY, Math.min(W, H) * 0.25);
    sunGlow.addColorStop(0, 'rgba(255, 250, 210, 0.95)');
    sunGlow.addColorStop(0.35, 'rgba(253, 230, 138, 0.45)');
    sunGlow.addColorStop(1, 'rgba(253, 230, 138, 0)');
    ctx.fillStyle = sunGlow;
    ctx.beginPath();
    ctx.arc(sunX, sunY, Math.min(W, H) * 0.25, 0, Math.PI * 2);
    ctx.fill();

    // Soft drifting clouds
    ctx.fillStyle = 'rgba(255, 255, 255, 0.58)';
    for (let i = 0; i < 3; i++) {
      const cx = ((W * (0.2 + i * 0.32) + time * (6 + i * 2)) % (W + 160)) - 80 - camLean * 5;
      const cy = horizonY * (0.24 + (i % 2) * 0.16);
      const cw = 54 + i * 14;
      ctx.beginPath();
      ctx.ellipse(cx, cy, cw, cw * 0.34, 0, 0, Math.PI * 2);
      ctx.ellipse(cx - cw * 0.4, cy + 4, cw * 0.55, cw * 0.26, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + cw * 0.42, cy + 5, cw * 0.5, cw * 0.24, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Far misty mountain silhouettes
    ctx.fillStyle = '#5BA67E';
    ctx.beginPath();
    ctx.moveTo(-20, horizonY + 8);
    ctx.quadraticCurveTo(W * 0.18 - camLean * 6, horizonY - 68, W * 0.38 - camLean * 6, horizonY - 14);
    ctx.quadraticCurveTo(W * 0.62 - camLean * 6, horizonY - 78, W * 0.85 - camLean * 6, horizonY - 18);
    ctx.lineTo(W + 20, horizonY + 8);
    ctx.closePath();
    ctx.fill();

    // Closer lush bamboo hill ridge
    ctx.fillStyle = '#337D55';
    ctx.beginPath();
    ctx.moveTo(-20, horizonY + 10);
    ctx.quadraticCurveTo(W * 0.25 - camLean * 10, horizonY - 40, W * 0.5 - camLean * 10, horizonY - 6);
    ctx.quadraticCurveTo(W * 0.78 - camLean * 10, horizonY - 46, W + 20, horizonY + 10);
    ctx.closePath();
    ctx.fill();
  }

  private drawGroundAndTrack(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    scrollDistance: number,
    camLean: number
  ): void {
    const horizonY = H * 0.33;

    // Lush forest floor grass
    const grassGrad = ctx.createLinearGradient(0, horizonY, 0, H);
    grassGrad.addColorStop(0, '#2B6E44');
    grassGrad.addColorStop(0.45, '#1F5D37');
    grassGrad.addColorStop(1, '#144426');
    ctx.fillStyle = grassGrad;
    ctx.fillRect(-20, horizonY, W + 40, H - horizonY + 20);

    // 3-lane dirt path trapezoid
    const farLeft = this.project(1.0, -1.62, camLean);
    const farRight = this.project(1.0, 1.62, camLean);
    const nearLeft = this.project(-0.08, -1.62, camLean);
    const nearRight = this.project(-0.08, 1.62, camLean);

    // Path border grass shadow
    ctx.fillStyle = '#4A3621';
    ctx.beginPath();
    ctx.moveTo(farLeft.x - 6, farLeft.y);
    ctx.lineTo(farRight.x + 6, farRight.y);
    ctx.lineTo(nearRight.x + 22, nearRight.y);
    ctx.lineTo(nearLeft.x - 22, nearLeft.y);
    ctx.closePath();
    ctx.fill();

    // Dirt surface gradient
    const dirtGrad = ctx.createLinearGradient(0, horizonY, 0, H);
    dirtGrad.addColorStop(0, '#9E774D');
    dirtGrad.addColorStop(0.5, '#B68A59');
    dirtGrad.addColorStop(1, '#8C6239');
    ctx.fillStyle = dirtGrad;
    ctx.beginPath();
    ctx.moveTo(farLeft.x, farLeft.y);
    ctx.lineTo(farRight.x, farRight.y);
    ctx.lineTo(nearRight.x, nearRight.y);
    ctx.lineTo(nearLeft.x, nearLeft.y);
    ctx.closePath();
    ctx.fill();

    // Subtle sunlit center glow on trail
    const centerTrailGrad = ctx.createLinearGradient(0, horizonY, 0, H);
    centerTrailGrad.addColorStop(0, 'rgba(255, 236, 179, 0.28)');
    centerTrailGrad.addColorStop(1, 'rgba(255, 236, 179, 0.04)');
    ctx.fillStyle = centerTrailGrad;
    const farInnerL = this.project(1.0, -0.55, camLean);
    const farInnerR = this.project(1.0, 0.55, camLean);
    const nearInnerL = this.project(-0.08, -0.55, camLean);
    const nearInnerR = this.project(-0.08, 0.55, camLean);
    ctx.beginPath();
    ctx.moveTo(farInnerL.x, farInnerL.y);
    ctx.lineTo(farInnerR.x, farInnerR.y);
    ctx.lineTo(nearInnerR.x, nearInnerR.y);
    ctx.lineTo(nearInnerL.x, nearInnerL.y);
    ctx.closePath();
    ctx.fill();

    // Scrolling lane divider markers & ground texture stripes
    const numStripes = 10;
    const cycle = (scrollDistance * 0.14) % 1;
    for (let i = 0; i < numStripes; i++) {
      const z = 1.0 - ((i + cycle) / numStripes) * 1.08;
      if (z < -0.06 || z > 0.99) continue;

      const leftDiv = this.project(z, -0.5, camLean);
      const rightDiv = this.project(z, 0.5, camLean);
      const segW = Math.max(2, 4.5 * leftDiv.scale);
      const segH = Math.max(4, 16 * leftDiv.scale);

      ctx.fillStyle = 'rgba(255, 244, 214, 0.35)';
      ctx.beginPath();
      ctx.ellipse(leftDiv.x, leftDiv.y, segW, segH * 0.45, 0, 0, Math.PI * 2);
      ctx.ellipse(rightDiv.x, rightDiv.y, segW, segH * 0.45, 0, 0, Math.PI * 2);
      ctx.fill();

      // Small pebbles on track edges
      const pebbleL = this.project(z, -1.35, camLean);
      const pebbleR = this.project(z, 1.35, camLean);
      ctx.fillStyle = 'rgba(70, 50, 28, 0.32)';
      ctx.beginPath();
      ctx.ellipse(pebbleL.x, pebbleL.y, 7 * pebbleL.scale, 3.5 * pebbleL.scale, 0, 0, Math.PI * 2);
      ctx.ellipse(pebbleR.x, pebbleR.y, 7 * pebbleR.scale, 3.5 * pebbleR.scale, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawSideBambooForest(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    scrollDistance: number,
    time: number,
    camLean: number
  ): void {
    const count = 9;
    const cycle = (scrollDistance * 0.11) % 1;

    for (let i = 0; i < count; i++) {
      const z = 1.0 - ((i + cycle) / count) * 1.1;
      if (z < -0.08 || z > 0.98) continue;

      const sway = Math.sin(time * 2.1 + i * 1.3) * 4;

      // Left & right bamboo clusters
      [-1, 1].forEach((side) => {
        const pt = this.project(z, side * 1.95, camLean);
        const s = pt.scale;
        const stalkW = 14 * s;
        const stalkH = Math.min(H * 0.55, 270 * s);

        // Ground shadow
        ctx.fillStyle = 'rgba(10, 35, 18, 0.32)';
        ctx.beginPath();
        ctx.ellipse(pt.x, pt.y + 3 * s, 26 * s, 8 * s, 0, 0, Math.PI * 2);
        ctx.fill();

        // Secondary background stalk
        this.drawBambooStalk(
          ctx,
          pt.x + side * 24 * s,
          pt.y - 6 * s,
          stalkW * 0.8,
          stalkH * 0.88,
          sway * 0.7 * s,
          '#1C5E36',
          '#2D804B'
        );

        // Primary foreground stalk
        this.drawBambooStalk(
          ctx,
          pt.x,
          pt.y,
          stalkW,
          stalkH,
          sway * s,
          '#257945',
          '#47AE68'
        );

        // Wooden trail fence post matching sunlit forest path
        const fencePt = this.project(z, side * 1.68, camLean);
        const fs = fencePt.scale;
        ctx.fillStyle = '#B45309';
        ctx.strokeStyle = '#451A03';
        ctx.lineWidth = Math.max(1, 1.5 * fs);
        ctx.beginPath();
        ctx.roundRect(fencePt.x - 4 * fs, fencePt.y - 24 * fs, 8 * fs, 26 * fs, 2 * fs);
        ctx.fill();
        ctx.stroke();

        // Lush fern bush at base
        ctx.fillStyle = '#2A854B';
        ctx.beginPath();
        ctx.ellipse(pt.x - side * 8 * s, pt.y - 4 * s, 22 * s, 12 * s, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#43AA64';
        ctx.beginPath();
        ctx.ellipse(pt.x - side * 4 * s, pt.y - 8 * s, 15 * s, 8 * s, 0, 0, Math.PI * 2);
        ctx.fill();
      });
    }
  }

  private drawBambooStalk(
    ctx: CanvasRenderingContext2D,
    x: number,
    baseY: number,
    w: number,
    h: number,
    sway: number,
    darkColor: string,
    lightColor: string
  ): void {
    const segments = 4;
    const segH = h / segments;
    for (let s = 0; s < segments; s++) {
      const y0 = baseY - s * segH;
      const y1 = y0 - segH + 2;
      const x0 = x + (sway * s) / segments;
      const x1 = x + (sway * (s + 1)) / segments;

      const grad = ctx.createLinearGradient(x0 - w * 0.5, 0, x0 + w * 0.5, 0);
      grad.addColorStop(0, darkColor);
      grad.addColorStop(0.45, lightColor);
      grad.addColorStop(1, darkColor);

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(x0 - w * 0.5, y0);
      ctx.lineTo(x1 - w * 0.48, y1);
      ctx.lineTo(x1 + w * 0.48, y1);
      ctx.lineTo(x0 + w * 0.5, y0);
      ctx.closePath();
      ctx.fill();

      // Bamboo joint ring
      ctx.fillStyle = '#86EFAC';
      ctx.fillRect(x1 - w * 0.56, y1 - 1.5, w * 1.12, Math.max(2, w * 0.18));

      // Occasional leaves
      if (s >= 1) {
        const dir = s % 2 === 0 ? 1 : -1;
        ctx.fillStyle = lightColor;
        ctx.beginPath();
        ctx.ellipse(
          x1 + dir * w * 1.2,
          y1 - w * 0.3,
          w * 1.1,
          w * 0.32,
          dir * -0.45,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    }
  }

  private drawObstacle(
    ctx: CanvasRenderingContext2D,
    obs: ObstacleEntity,
    time: number,
    camLean: number
  ): void {
    const pt = this.project(obs.z, obs.lane, camLean);
    const s = pt.scale;
    const x = pt.x;
    const y = pt.y;

    // Ground shadow
    ctx.fillStyle = 'rgba(20, 16, 10, 0.34)';
    ctx.beginPath();
    ctx.ellipse(x, y + 3 * s, 38 * s, 11 * s, 0, 0, Math.PI * 2);
    ctx.fill();

    switch (obs.type) {
      case 'small_rock': {
        this.drawRock(ctx, x, y, 32 * s, 26 * s, '#64748B', '#94A3B8', true);
        break;
      }
      case 'large_rock': {
        this.drawRock(ctx, x, y, 48 * s, 78 * s, '#475569', '#64748B', true);
        // Subtle red/amber moss warning berries on top so player knows it's tall
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.arc(x - 10 * s, y - 54 * s, 4 * s, 0, Math.PI * 2);
        ctx.arc(x + 12 * s, y - 48 * s, 3.5 * s, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'fallen_bamboo': {
        // Tied bundle of 3 green bamboo poles across the lane
        const w = 82 * s;
        const h = 15 * s;
        for (let row = 0; row < 2; row++) {
          const ry = y - 10 * s - row * 13 * s;
          const grad = ctx.createLinearGradient(0, ry - h * 0.5, 0, ry + h * 0.5);
          grad.addColorStop(0, '#86EFAC');
          grad.addColorStop(0.5, '#22C55E');
          grad.addColorStop(1, '#14532D');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(x - w * 0.5, ry - h * 0.5, w, h, 7 * s);
          ctx.fill();
          ctx.strokeStyle = '#0F3D22';
          ctx.lineWidth = Math.max(1, 2 * s);
          ctx.stroke();

          // Joints
          ctx.fillStyle = '#BBF7D0';
          ctx.fillRect(x - w * 0.2, ry - h * 0.5, 3 * s, h);
          ctx.fillRect(x + w * 0.2, ry - h * 0.5, 3 * s, h);
        }
        // Bright red hazard rope ties (clear visual contrast!)
        ctx.fillStyle = '#EF4444';
        ctx.fillRect(x - w * 0.34, y - 30 * s, 7 * s, 26 * s);
        ctx.fillRect(x + w * 0.27, y - 30 * s, 7 * s, 26 * s);
        break;
      }
      case 'wooden_log': {
        const w = 84 * s;
        const h = 30 * s;
        const ly = y - h * 0.55;
        const grad = ctx.createLinearGradient(0, ly - h * 0.5, 0, ly + h * 0.5);
        grad.addColorStop(0, '#A16227');
        grad.addColorStop(0.5, '#78350F');
        grad.addColorStop(1, '#451A03');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x - w * 0.5, ly - h * 0.5, w, h, 10 * s);
        ctx.fill();
        ctx.strokeStyle = '#2E1103';
        ctx.lineWidth = Math.max(1, 2 * s);
        ctx.stroke();

        // Exposed wood ring end on right
        ctx.fillStyle = '#FDE68A';
        ctx.beginPath();
        ctx.ellipse(x + w * 0.46, ly, 8 * s, h * 0.46, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#92400E';
        ctx.lineWidth = Math.max(1, 1.5 * s);
        ctx.stroke();

        // Moss patch on top
        ctx.fillStyle = '#4ADE80';
        ctx.beginPath();
        ctx.ellipse(x - 10 * s, ly - h * 0.44, 18 * s, 5 * s, 0, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'tree_roots': {
        // Gnarled creeping roots arching low over the ground
        ctx.strokeStyle = '#3E1C0A';
        ctx.lineWidth = Math.max(2, 12 * s);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x - 42 * s, y);
        ctx.quadraticCurveTo(x - 16 * s, y - 34 * s, x + 6 * s, y - 4 * s);
        ctx.quadraticCurveTo(x + 24 * s, y - 28 * s, x + 42 * s, y);
        ctx.stroke();

        ctx.strokeStyle = '#854D0E';
        ctx.lineWidth = Math.max(1.5, 7 * s);
        ctx.stroke();

        // Little green sprouts on root
        ctx.fillStyle = '#4ADE80';
        ctx.beginPath();
        ctx.ellipse(x - 16 * s, y - 22 * s, 7 * s, 3.5 * s, -0.5, 0, Math.PI * 2);
        ctx.ellipse(x + 22 * s, y - 18 * s, 6 * s, 3 * s, 0.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'high_bamboo_gate': {
        // Tall left/right posts + elevated crossbar (CLEAR GAP UNDERNEATH TO SLIDE!)
        const halfSpan = 42 * s;
        const postH = 88 * s;
        const barY = y - 54 * s; // High enough to slide under, hits standing panda!

        // Posts
        ctx.fillStyle = '#15803D';
        ctx.strokeStyle = '#052E16';
        ctx.lineWidth = Math.max(1, 2 * s);
        [-1, 1].forEach((side) => {
          const px = x + side * halfSpan;
          ctx.beginPath();
          ctx.roundRect(px - 6 * s, y - postH, 12 * s, postH, 4 * s);
          ctx.fill();
          ctx.stroke();
        });

        // Crossbar
        const barGrad = ctx.createLinearGradient(0, barY - 12 * s, 0, barY + 12 * s);
        barGrad.addColorStop(0, '#FDE047');
        barGrad.addColorStop(0.45, '#EF4444');
        barGrad.addColorStop(1, '#991B1B');
        ctx.fillStyle = barGrad;
        ctx.beginPath();
        ctx.roundRect(x - halfSpan - 8 * s, barY - 11 * s, (halfSpan + 8 * s) * 2, 22 * s, 6 * s);
        ctx.fill();
        ctx.strokeStyle = '#450A0A';
        ctx.stroke();

        // Downward chevron / ribbon telegraph ("SLIDE!")
        const flutter = Math.sin(time * 7 + obs.lane) * 4 * s;
        ctx.fillStyle = '#FACC15';
        for (let r = -1; r <= 1; r++) {
          const rx = x + r * 22 * s;
          ctx.beginPath();
          ctx.moveTo(rx - 5 * s, barY + 11 * s);
          ctx.lineTo(rx + 5 * s, barY + 11 * s);
          ctx.lineTo(rx + flutter, barY + 25 * s);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
    }
  }

  private drawRock(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    rx: number,
    ry: number,
    dark: string,
    light: string,
    hasMoss: boolean
  ): void {
    const grad = ctx.createLinearGradient(x - rx, y - ry, x + rx, y);
    grad.addColorStop(0, light);
    grad.addColorStop(1, dark);

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(x - rx, y);
    ctx.quadraticCurveTo(x - rx * 0.9, y - ry * 0.85, x - rx * 0.15, y - ry);
    ctx.quadraticCurveTo(x + rx * 0.75, y - ry * 0.9, x + rx, y);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = Math.max(1, rx * 0.06);
    ctx.stroke();

    if (hasMoss) {
      ctx.fillStyle = '#22C55E';
      ctx.beginPath();
      ctx.ellipse(x - rx * 0.18, y - ry * 0.74, rx * 0.42, ry * 0.16, -0.15, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawCollectible(
    ctx: CanvasRenderingContext2D,
    col: CollectibleEntity,
    time: number,
    camLean: number
  ): void {
    const pt = this.project(col.z, col.lane, camLean);
    const s = pt.scale;
    const isGolden = col.type === 'golden_bamboo';
    const bob = Math.sin(time * 5.2 + col.bobPhase) * 6 * s;
    const lift = col.yOffset * 58 * s;

    // Ground shadow
    ctx.fillStyle = isGolden ? 'rgba(234, 179, 8, 0.38)' : 'rgba(20, 35, 18, 0.28)';
    ctx.beginPath();
    ctx.ellipse(pt.x, pt.y + 2 * s, 16 * s, 5.5 * s, 0, 0, Math.PI * 2);
    ctx.fill();

    const cx = pt.x;
    const cy = pt.y - 26 * s - lift + bob;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(Math.sin(time * 3.5 + col.bobPhase) * 0.14);

    // Outer glow aura
    const auraR = (isGolden ? 28 : 21) * s;
    const aura = ctx.createRadialGradient(0, 0, 2 * s, 0, 0, auraR);
    aura.addColorStop(0, isGolden ? 'rgba(250, 204, 21, 0.7)' : 'rgba(74, 222, 128, 0.5)');
    aura.addColorStop(1, 'rgba(74, 222, 128, 0)');
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(0, 0, auraR, 0, Math.PI * 2);
    ctx.fill();

    // Segmented bamboo piece
    const bw = 13 * s;
    const bh = 32 * s;
    const grad = ctx.createLinearGradient(-bw * 0.5, 0, bw * 0.5, 0);
    if (isGolden) {
      grad.addColorStop(0, '#CA8A04');
      grad.addColorStop(0.45, '#FEF08A');
      grad.addColorStop(1, '#A16207');
    } else {
      grad.addColorStop(0, '#15803D');
      grad.addColorStop(0.45, '#86EFAC');
      grad.addColorStop(1, '#166534');
    }

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(-bw * 0.5, -bh * 0.5, bw, bh, 4 * s);
    ctx.fill();
    ctx.strokeStyle = isGolden ? '#713F12' : '#052E16';
    ctx.lineWidth = Math.max(1, 1.8 * s);
    ctx.stroke();

    // Node ring
    ctx.fillStyle = isGolden ? '#FEF9C3' : '#DCFCE7';
    ctx.fillRect(-bw * 0.58, -1.5 * s, bw * 1.16, 3 * s);

    // Fresh leaf sprout
    ctx.fillStyle = isGolden ? '#FDE047' : '#4ADE80';
    ctx.beginPath();
    ctx.ellipse(bw * 0.65, -bh * 0.3, 8 * s, 3.2 * s, -0.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawPanda(
    ctx: CanvasRenderingContext2D,
    world: RenderWorldState,
    camLean: number
  ): void {
    const p = world.player;
    // On MENU and LOADING, the official uploaded mascot artwork is displayed in the UI
    if (p.state === 'MENU' || p.state === 'LOADING') {
      return;
    }

    const playerZ = 0.08;
    const pt = this.project(playerZ, p.laneX, camLean);
    const s = pt.scale;
    const jumpPixels = p.jumpY * 115 * s;

    // Ground shadow (shrinks gracefully as panda jumps high)
    const shadowScale = Math.max(0.42, 1 - p.jumpY * 0.45);
    ctx.fillStyle = 'rgba(12, 20, 14, 0.38)';
    ctx.beginPath();
    ctx.ellipse(pt.x, pt.y + 4 * s, 32 * s * shadowScale, 10 * s * shadowScale, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.translate(pt.x, pt.y - jumpPixels);

    // Game Over dizzy panda turning around with stars!
    if (p.state === 'GAME_OVER') {
      const wobble = Math.sin(p.dizzyTime * 8) * 0.08;
      ctx.rotate(wobble);
      ctx.scale(s * 1.1, s * 1.1);
      this.drawDizzyPanda(ctx, p.dizzyTime);
      ctx.restore();
      return;
    }

    // Active Running / Jumping / Sliding Panda (3-quarter back-runner view)
    ctx.rotate(p.bankAngle);
    ctx.scale(s * p.squashX, s * p.squashY);

    if (p.isSliding) {
      this.drawSlidingPanda(ctx, world.time);
    } else {
      this.drawRunningPanda(ctx, p.runCycle, p.jumpY > 0.05, world.time);
    }

    ctx.restore();
  }

  private drawGreenScarfTails(
    ctx: CanvasRenderingContext2D,
    anchorX: number,
    anchorY: number,
    time: number,
    scale = 1
  ): void {
    const wave1 = Math.sin(time * 13) * 5 * scale;
    const wave2 = Math.cos(time * 11) * 4 * scale;

    ctx.save();
    ctx.strokeStyle = '#14532D';
    ctx.lineWidth = 2.2;

    // Upper flowing green scarf tail
    ctx.fillStyle = '#22C55E';
    ctx.beginPath();
    ctx.moveTo(anchorX, anchorY);
    ctx.quadraticCurveTo(anchorX - 18 * scale, anchorY - 12 * scale + wave1, anchorX - 34 * scale, anchorY - 5 * scale + wave1);
    ctx.quadraticCurveTo(anchorX - 20 * scale, anchorY + 2 * scale + wave1 * 0.6, anchorX, anchorY + 5 * scale);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Lower flowing green scarf tail
    ctx.fillStyle = '#4ADE80';
    ctx.beginPath();
    ctx.moveTo(anchorX + 2 * scale, anchorY + 3 * scale);
    ctx.quadraticCurveTo(anchorX - 14 * scale, anchorY + 6 * scale + wave2, anchorX - 28 * scale, anchorY + 13 * scale + wave2);
    ctx.quadraticCurveTo(anchorX - 14 * scale, anchorY + 15 * scale + wave2 * 0.6, anchorX + 2 * scale, anchorY + 8 * scale);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  private drawRunningPanda(
    ctx: CanvasRenderingContext2D,
    runCycle: number,
    isJumping: boolean,
    time: number
  ): void {
    const legSwing = isJumping ? 0.55 : Math.sin(runCycle);
    const armSwing = isJumping ? -0.8 : Math.cos(runCycle);
    const bob = isJumping ? -4 : Math.abs(Math.sin(runCycle)) * 5;

    ctx.translate(0, -bob);

    // Left & Right Legs pumping with warm beige/pink paw pads matching mascot
    [-1, 1].forEach((side) => {
      const swing = side * legSwing;
      const ly = -12 + swing * 7;
      const lx = side * 14;
      ctx.fillStyle = '#1F2937';
      ctx.beginPath();
      ctx.ellipse(lx, ly, 9.5, 11, swing * 0.25, 0, Math.PI * 2);
      ctx.fill();
      if (swing > 0.1) {
        ctx.fillStyle = '#E7B8A4';
        ctx.beginPath();
        ctx.ellipse(lx, ly + 2, 4.5, 5.2, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Arms pumping on sides
    [-1, 1].forEach((side) => {
      const swing = side * armSwing;
      ctx.fillStyle = '#1F2937';
      ctx.beginPath();
      ctx.ellipse(side * 27, -36 + swing * 7, 8, 13, side * 0.3, 0, Math.PI * 2);
      ctx.fill();
    });

    // Chubby round white torso
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(0, -34, 26, 23, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Charcoal shoulder band
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(0, -45, 25, 9, 0, Math.PI, Math.PI * 2);
    ctx.fill();

    // Cute fluffy white tail
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -22, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Flowing Green Scarf around neck (matching mascot!)
    this.drawGreenScarfTails(ctx, -10, -48, time, 1);
    ctx.fillStyle = '#22C55E';
    ctx.strokeStyle = '#14532D';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(-21, -48);
    ctx.quadraticCurveTo(0, -36, 21, -48);
    ctx.quadraticCurveTo(0, -54, -21, -48);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Ears
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.arc(-20, -78, 10.5, 0, Math.PI * 2);
    ctx.arc(20, -78, 10.5, 0, Math.PI * 2);
    ctx.fill();

    // Head with cute spiky fur tuft on top
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(0, -64, 24, 21, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Top spiky white fur tuft
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(-8, -83);
    ctx.lineTo(-3, -90);
    ctx.lineTo(1, -84);
    ctx.lineTo(5, -90);
    ctx.lineTo(9, -83);
    ctx.stroke();
  }

  private drawSlidingPanda(ctx: CanvasRenderingContext2D, time: number): void {
    // Aerodynamic low belly-slide pose with trailing green scarf!
    this.drawGreenScarfTails(ctx, -12, -26, time, 0.9);

    // Tucked legs trailing
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(-18, -10, 12, 8, 0.2, 0, Math.PI * 2);
    ctx.ellipse(18, -10, 12, 8, -0.2, 0, Math.PI * 2);
    ctx.fill();

    // Flattened white body
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(0, -17, 30, 15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Green scarf collar
    ctx.fillStyle = '#22C55E';
    ctx.strokeStyle = '#14532D';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(0, -24, 22, 6, 0, 0, Math.PI);
    ctx.fill();
    ctx.stroke();

    // Low tucked head
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.arc(-18, -36, 8, 0, Math.PI * 2);
    ctx.arc(18, -36, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(0, -26, 22, 15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  private drawDizzyPanda(ctx: CanvasRenderingContext2D, dizzyTime: number): void {
    // Sitting bumped panda facing camera with green scarf & orbiting stars
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(-20, -7, 11, 8, -0.2, 0, Math.PI * 2);
    ctx.ellipse(20, -7, 11, 8, 0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(0, -26, 27, 23, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(0, -36, 26, 9, 0, 0, Math.PI);
    ctx.fill();

    // Green Scarf collar
    ctx.fillStyle = '#22C55E';
    ctx.strokeStyle = '#14532D';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-22, -40);
    ctx.lineTo(0, -28);
    ctx.lineTo(22, -40);
    ctx.quadraticCurveTo(0, -45, -22, -40);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Ears
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.arc(-21, -72, 10.5, 0, Math.PI * 2);
    ctx.arc(21, -72, 10.5, 0, Math.PI * 2);
    ctx.fill();

    // Head
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(0, -56, 26, 22, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Dizzy X eyes
    ctx.fillStyle = '#1F2937';
    ctx.beginPath();
    ctx.ellipse(-10, -56, 7.5, 8.5, 0.2, 0, Math.PI * 2);
    ctx.ellipse(10, -56, 7.5, 8.5, -0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    [-10, 10].forEach((ex) => {
      ctx.beginPath();
      ctx.moveTo(ex - 3, -59);
      ctx.lineTo(ex + 3, -53);
      ctx.moveTo(ex + 3, -59);
      ctx.lineTo(ex - 3, -53);
      ctx.stroke();
    });

    // Surprised mouth
    ctx.fillStyle = '#EF4444';
    ctx.beginPath();
    ctx.arc(0, -45, 4.5, 0, Math.PI * 2);
    ctx.fill();

    // Orbiting dizzy yellow stars
    for (let i = 0; i < 3; i++) {
      const angle = dizzyTime * 5 + (i * Math.PI * 2) / 3;
      const sx = Math.cos(angle) * 26;
      const sy = -88 + Math.sin(angle) * 7;
      this.drawStarShape(ctx, sx, sy, 5.5, '#FACC15');
    }
  }

  private drawSpeedLines(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    speedMult: number,
    time: number
  ): void {
    const alpha = Math.min(0.28, (speedMult - 1.35) * 0.25);
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.lineWidth = 2;
    for (let i = 0; i < 8; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      const yOffset = ((time * 900 + i * 130) % (H * 0.7)) + H * 0.25;
      const xStart = side > 0 ? W * 0.88 - (i * 11) % 45 : W * 0.12 + (i * 11) % 45;
      ctx.beginPath();
      ctx.moveTo(xStart, yOffset);
      ctx.lineTo(xStart + side * 14, yOffset + 48);
      ctx.stroke();
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D, particles: ParticleEntity[]): void {
    for (let i = 0; i < particles.length; i++) {
      const pt = particles[i];
      if (!pt.active) continue;
      const alpha = Math.max(0, pt.life / pt.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.rotation);

      if (pt.shape === 'circle') {
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(0, 0, pt.size * alpha, 0, Math.PI * 2);
        ctx.fill();
      } else if (pt.shape === 'leaf') {
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.ellipse(0, 0, pt.size * 1.4, pt.size * 0.65, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (pt.shape === 'star') {
        this.drawStarShape(ctx, 0, 0, pt.size, pt.color);
      } else if (pt.shape === 'ring') {
        ctx.strokeStyle = pt.color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, pt.size * (1.8 - alpha * 0.8), 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private drawStarShape(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    r: number,
    color: string
  ): void {
    ctx.fillStyle = color;
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const rad = i % 2 === 0 ? r : r * 0.42;
      const a = (i * Math.PI) / 4;
      const px = x + Math.cos(a) * rad;
      const py = y + Math.sin(a) * rad;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  }

  private drawFloatingTexts(
    ctx: CanvasRenderingContext2D,
    texts: FloatingTextEntity[]
  ): void {
    for (let i = 0; i < texts.length; i++) {
      const ft = texts[i];
      if (!ft.active) continue;
      const alpha = Math.max(0, ft.life / ft.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = `800 ${Math.round(18 * ft.scale)}px Outfit, system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(11, 36, 24, 0.85)';
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    }
  }
}
