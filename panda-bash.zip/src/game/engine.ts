import { audioEngine } from './audio';
import { PandaCanvasRenderer } from './renderer';
import {
  CollectibleEntity,
  FloatingTextEntity,
  GameState,
  HudSnapshot,
  LaneIndex,
  ObstacleAvoidance,
  ObstacleEntity,
  ObstacleType,
  ParticleEntity,
} from './types';

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onStateChange: (state: GameState) => void;
  onGameOver: (stats: {
    score: number;
    bamboo: number;
    distance: number;
    hitObstacle: ObstacleType | null;
  }) => void;
}

const OBSTACLE_AVOIDANCE_MAP: Record<ObstacleType, ObstacleAvoidance> = {
  small_rock: 'jump',
  large_rock: 'switch',
  fallen_bamboo: 'jump',
  wooden_log: 'jump',
  tree_roots: 'jump',
  high_bamboo_gate: 'slide',
};

const JUMPABLE_TYPES: ObstacleType[] = [
  'small_rock',
  'fallen_bamboo',
  'wooden_log',
  'tree_roots',
];

const ALL_LANES: LaneIndex[] = [-1, 0, 1];

export class PandaGameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private renderer = new PandaCanvasRenderer();
  private callbacks: EngineCallbacks;

  private rafId: number | null = null;
  private lastTimestamp = 0;
  private elapsedTime = 0;
  private gameState: GameState = 'LOADING';

  // Player Physics & Animation State
  private targetLane: LaneIndex = 0;
  private laneX = 0;
  private bankAngle = 0;
  private jumpY = 0;
  private jumpVel = 0;
  private isSliding = false;
  private slideTimer = 0;
  private slideDuration = 0.64;
  private runCycle = 0;
  private lastFootstepCycle = 0;
  private squashX = 1;
  private squashY = 1;

  // Input Buffering (feels super crisp on mobile & desktop!)
  private bufferedJumpTimer = 0;
  private bufferedSlideTimer = 0;

  // Game Progression & Scoring
  private score = 0;
  private bambooCount = 0;
  private distanceMeters = 0;
  private scrollDistance = 0;
  private speedMultiplier = 1.0;
  private combo = 0;
  private comboTimer = 0;
  private countdownTimer = 0;
  private lastCountdownInt = -1;
  private hitstopTimer = 0;
  private hitFlash = 0;
  private shakeTimer = 0;
  private shakeMagnitude = 0;
  private dizzyTime = 0;
  private bestScoreRef = 0;
  private passedNewRecordThisRun = false;

  // Spawner
  private spawnCooldown = 0.9;
  private patternIndex = 0;

  // Pre-allocated Entity Pools (zero GC pressure!)
  private obstacles: ObstacleEntity[] = [];
  private collectibles: CollectibleEntity[] = [];
  private particles: ParticleEntity[] = [];
  private floatingTexts: FloatingTextEntity[] = [];

  // Throttled HUD diffing
  private lastHudSent: HudSnapshot = {
    score: -1,
    bamboo: -1,
    distance: -1,
    speedMultiplier: 1,
    combo: 0,
    countdownValue: 3,
    isNewRecord: false,
  };

  // Touch Gesture Tracking
  private touchActive = false;
  private touchStartX = 0;
  private touchStartY = 0;
  private swipeHandled = false;

  constructor(canvas: HTMLCanvasElement, callbacks: EngineCallbacks) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('2D Canvas context not supported');
    }
    this.ctx = context;
    this.callbacks = callbacks;

    this.initPools();
    this.handleResize();
  }

  private initPools(): void {
    for (let i = 0; i < 28; i++) {
      this.obstacles.push({
        active: false,
        type: 'small_rock',
        avoidance: 'jump',
        lane: 0,
        z: 1,
        passed: false,
      });
    }
    for (let i = 0; i < 48; i++) {
      this.collectibles.push({
        active: false,
        type: 'bamboo',
        lane: 0,
        z: 1,
        yOffset: 0,
        bobPhase: 0,
        collected: false,
      });
    }
    for (let i = 0; i < 90; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        size: 4,
        life: 0,
        maxLife: 1,
        color: '#fff',
        shape: 'circle',
        rotation: 0,
        vRot: 0,
      });
    }
    for (let i = 0; i < 16; i++) {
      this.floatingTexts.push({
        active: false,
        x: 0,
        y: 0,
        vy: -40,
        text: '',
        color: '#fff',
        life: 0,
        maxLife: 1,
        scale: 1,
      });
    }
  }

  public startLoop(): void {
    if (this.rafId !== null) return;
    this.lastTimestamp = performance.now();
    const tick = (now: number) => {
      const rawDt = (now - this.lastTimestamp) / 1000;
      this.lastTimestamp = now;
      const dt = Math.min(Math.max(rawDt, 0), 0.05);
      this.update(dt);
      this.render();
      this.rafId = window.requestAnimationFrame(tick);
    };
    this.rafId = window.requestAnimationFrame(tick);
  }

  public stopLoop(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public handleResize = (): void => {
    this.renderer.resize(this.canvas);
  };

  public setBestScore(best: number): void {
    this.bestScoreRef = best;
  }

  public getState(): GameState {
    return this.gameState;
  }

  public setState(next: GameState): void {
    this.gameState = next;
    this.callbacks.onStateChange(next);
  }

  public goToMenu(): void {
    this.clearEntities();
    this.resetPlayer();
    this.speedMultiplier = 1.0;
    audioEngine.setSpeedIntensity(1.0);
    audioEngine.setMusicTrack('menu');
    this.setState('MENU');
  }

  public startNewRun(bestScore: number): void {
    this.bestScoreRef = bestScore;
    this.passedNewRecordThisRun = false;
    this.clearEntities();
    this.resetPlayer();

    this.score = 0;
    this.bambooCount = 0;
    this.distanceMeters = 0;
    this.speedMultiplier = 1.0;
    this.combo = 0;
    this.comboTimer = 0;
    this.spawnCooldown = 0.6;
    this.hitstopTimer = 0;
    this.hitFlash = 0;
    this.shakeTimer = 0;
    this.dizzyTime = 0;

    this.countdownTimer = 2.6;
    this.lastCountdownInt = 4;

    audioEngine.unlock();
    audioEngine.setSpeedIntensity(1.0);
    audioEngine.setMusicTrack('gameplay');

    this.setState('COUNTDOWN');
    this.pushHudSnapshot(true);
  }

  public pause(): void {
    if (this.gameState !== 'PLAYING') return;
    audioEngine.playPause(true);
    this.setState('PAUSED');
  }

  public resume(): void {
    if (this.gameState !== 'PAUSED') return;
    audioEngine.playPause(false);
    this.lastTimestamp = performance.now();
    this.setState('PLAYING');
  }

  // ==================== INPUT ACTIONS ====================

  public moveLeft(): void {
    if (this.gameState !== 'PLAYING') return;
    if (this.targetLane > -1) {
      this.targetLane = (this.targetLane - 1) as LaneIndex;
      this.bankAngle = -0.18;
      audioEngine.playLaneSwitch();
    }
  }

  public moveRight(): void {
    if (this.gameState !== 'PLAYING') return;
    if (this.targetLane < 1) {
      this.targetLane = (this.targetLane + 1) as LaneIndex;
      this.bankAngle = 0.18;
      audioEngine.playLaneSwitch();
    }
  }

  public triggerJump(): void {
    if (this.gameState !== 'PLAYING') return;
    if (this.jumpY <= 0.04) {
      this.executeJump();
    } else {
      // Buffer jump slightly before landing
      this.bufferedJumpTimer = 0.14;
    }
  }

  public triggerSlide(): void {
    if (this.gameState !== 'PLAYING') return;
    if (this.jumpY > 0.08) {
      // Fast-fall while airborne + queue slide on landing!
      this.jumpVel = Math.min(this.jumpVel, -5.2);
      this.bufferedSlideTimer = 0.22;
      return;
    }
    this.executeSlide();
  }

  private executeJump(): void {
    this.jumpVel = 3.95;
    this.jumpY = 0.01;
    this.isSliding = false;
    this.slideTimer = 0;
    this.squashX = 0.84;
    this.squashY = 1.22;
    this.bufferedJumpTimer = 0;
    audioEngine.playJump();
    this.spawnDustBurst(this.laneX, 0.08, 6);
  }

  private executeSlide(): void {
    this.isSliding = true;
    this.slideTimer = this.slideDuration;
    this.squashX = 1.18;
    this.squashY = 0.78;
    this.bufferedSlideTimer = 0;
    audioEngine.playSlide();
    this.spawnDustBurst(this.laneX, 0.08, 5);
  }

  // ==================== TOUCH GESTURES ====================

  public onTouchStart = (e: TouchEvent): void => {
    if (this.gameState !== 'PLAYING' && this.gameState !== 'COUNTDOWN') return;
    if (e.touches.length === 0) return;
    const t = e.touches[0];
    this.touchActive = true;
    this.touchStartX = t.clientX;
    this.touchStartY = t.clientY;
    this.swipeHandled = false;
  };

  public onTouchMove = (e: TouchEvent): void => {
    if (!this.touchActive || this.swipeHandled || this.gameState !== 'PLAYING') return;
    if (e.touches.length === 0) return;
    const t = e.touches[0];
    const dx = t.clientX - this.touchStartX;
    const dy = t.clientY - this.touchStartY;
    const threshold = 26;

    if (Math.abs(dx) < threshold && Math.abs(dy) < threshold) return;

    this.swipeHandled = true;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) this.moveLeft();
      else this.moveRight();
    } else {
      if (dy < 0) this.triggerJump();
      else this.triggerSlide();
    }
  };

  public onTouchEnd = (): void => {
    this.touchActive = false;
    this.swipeHandled = false;
  };

  // ==================== SIMULATION UPDATE ====================

  private resetPlayer(): void {
    this.targetLane = 0;
    this.laneX = 0;
    this.bankAngle = 0;
    this.jumpY = 0;
    this.jumpVel = 0;
    this.isSliding = false;
    this.slideTimer = 0;
    this.runCycle = 0;
    this.lastFootstepCycle = 0;
    this.squashX = 1;
    this.squashY = 1;
    this.bufferedJumpTimer = 0;
    this.bufferedSlideTimer = 0;
  }

  private clearEntities(): void {
    for (let i = 0; i < this.obstacles.length; i++) this.obstacles[i].active = false;
    for (let i = 0; i < this.collectibles.length; i++) this.collectibles[i].active = false;
    for (let i = 0; i < this.particles.length; i++) this.particles[i].active = false;
    for (let i = 0; i < this.floatingTexts.length; i++) this.floatingTexts[i].active = false;
  }

  private update(dt: number): void {
    this.elapsedTime += dt;

    // Always update particles & floating texts even during hitstop/gameover
    this.updateParticles(dt);
    this.updateFloatingTexts(dt);

    if (this.hitFlash > 0) {
      this.hitFlash = Math.max(0, this.hitFlash - dt * 3.2);
    }
    if (this.shakeTimer > 0) {
      this.shakeTimer = Math.max(0, this.shakeTimer - dt);
    }

    if (this.gameState === 'LOADING' || this.gameState === 'MENU') {
      // Gentle idle world motion
      this.scrollDistance += dt * 1.1;
      return;
    }

    if (this.gameState === 'PAUSED') {
      return;
    }

    if (this.gameState === 'GAME_OVER') {
      this.dizzyTime += dt;
      return;
    }

    if (this.gameState === 'COUNTDOWN') {
      this.scrollDistance += dt * 3.8;
      this.runCycle += dt * 11;
      this.countdownTimer -= dt;
      const countInt = Math.max(0, Math.ceil(this.countdownTimer / 0.85));
      if (countInt !== this.lastCountdownInt) {
        this.lastCountdownInt = countInt;
        if (countInt > 0) {
          audioEngine.playCountdownTick(false);
        } else {
          audioEngine.playCountdownTick(true);
        }
        this.pushHudSnapshot(true);
      }
      if (this.countdownTimer <= 0) {
        this.setState('PLAYING');
        this.pushHudSnapshot(true);
      }
      return;
    }

    // Hitstop freeze frame on impact
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    // ==================== PLAYING STATE ====================
    // Smooth speed ramp (1.0x -> up to 2.55x over distance)
    this.speedMultiplier = Math.min(2.55, 1.0 + this.distanceMeters / 720);
    audioEngine.setSpeedIntensity(this.speedMultiplier);

    const worldZSpeed = 0.56 * this.speedMultiplier;
    const stepMeters = 14.5 * this.speedMultiplier * dt;
    this.distanceMeters += stepMeters;
    this.scrollDistance += 6.8 * this.speedMultiplier * dt;
    this.score += stepMeters * 1.25;

    if (this.bestScoreRef > 0 && !this.passedNewRecordThisRun && Math.floor(this.score) > this.bestScoreRef) {
      this.passedNewRecordThisRun = true;
      audioEngine.playCelebration();
      const pt = this.renderer.project(0.08, this.laneX, this.laneX);
      this.spawnFloatingText(pt.x, pt.y - 120 * pt.scale, 'NEW BEST!', '#FACC15', 1.25);
    }

    // Combo decay
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.combo = 0;
      }
    }

    // Smooth lane lerp
    const laneDiff = this.targetLane - this.laneX;
    this.laneX += laneDiff * Math.min(1, dt * 15);
    this.bankAngle += (laneDiff * 0.28 - this.bankAngle) * Math.min(1, dt * 14);

    // Squash & stretch recovery
    this.squashX += (1 - this.squashX) * Math.min(1, dt * 12);
    this.squashY += (1 - this.squashY) * Math.min(1, dt * 12);

    // Input buffer timers
    if (this.bufferedJumpTimer > 0) this.bufferedJumpTimer -= dt;
    if (this.bufferedSlideTimer > 0) this.bufferedSlideTimer -= dt;

    // Jump physics
    if (this.jumpY > 0 || this.jumpVel !== 0) {
      this.jumpY += this.jumpVel * dt;
      this.jumpVel -= 11.2 * dt; // crisp arcade gravity
      if (this.jumpY <= 0) {
        this.jumpY = 0;
        this.jumpVel = 0;
        this.squashX = 1.16;
        this.squashY = 0.84;
        this.spawnDustBurst(this.laneX, 0.08, 4);
        if (this.bufferedJumpTimer > 0) {
          this.executeJump();
        } else if (this.bufferedSlideTimer > 0) {
          this.executeSlide();
        }
      }
    }

    // Slide duration
    if (this.isSliding) {
      this.slideTimer -= dt;
      if (Math.random() < dt * 18) {
        this.spawnDustBurst(this.laneX, 0.08, 1);
      }
      if (this.slideTimer <= 0) {
        this.isSliding = false;
      }
    }

    // Running cycle & footsteps
    if (this.jumpY <= 0.02 && !this.isSliding) {
      this.runCycle += dt * (11.5 + this.speedMultiplier * 3.5);
      const stepIdx = Math.floor(this.runCycle / Math.PI);
      if (stepIdx !== this.lastFootstepCycle) {
        this.lastFootstepCycle = stepIdx;
        audioEngine.playFootstep();
        this.spawnDustBurst(this.laneX, 0.08, 1);
      }
    }

    // Spawn obstacles & bamboo patterns
    this.spawnCooldown -= dt * this.speedMultiplier;
    if (this.spawnCooldown <= 0) {
      this.spawnNextPattern();
      const minGap = Math.max(0.56, 1.18 - (this.speedMultiplier - 1) * 0.34);
      this.spawnCooldown = minGap + Math.random() * 0.36;
    }

    // Move & Collide Obstacles
    const playerZ = 0.08;
    for (let i = 0; i < this.obstacles.length; i++) {
      const obs = this.obstacles[i];
      if (!obs.active) continue;
      obs.z -= worldZSpeed * dt;

      if (obs.z < -0.18) {
        obs.active = false;
        continue;
      }

      // Collision window around playerZ (0.08)
      if (!obs.passed && Math.abs(obs.z - playerZ) < 0.052) {
        if (Math.abs(this.laneX - obs.lane) < 0.45) {
          if (this.checkObstacleHit(obs)) {
            this.handleCollision(obs.type);
            return;
          }
        }
      }
      if (obs.z < playerZ - 0.06 && !obs.passed) {
        obs.passed = true;
        this.score += 5; // Clean dodge bonus
      }
    }

    // Move & Collect Bamboo
    for (let i = 0; i < this.collectibles.length; i++) {
      const col = this.collectibles[i];
      if (!col.active) continue;
      col.z -= worldZSpeed * dt;

      if (col.z < -0.18) {
        col.active = false;
        continue;
      }

      if (!col.collected && Math.abs(col.z - playerZ) < 0.07) {
        const laneMatch = Math.abs(this.laneX - col.lane) < 0.56;
        const heightMatch =
          col.yOffset > 0.3
            ? this.jumpY > 0.25
            : this.jumpY < 0.68;
        if (laneMatch && heightMatch) {
          this.collectBamboo(col);
        }
      }
    }

    this.pushHudSnapshot(false);
  }

  private checkObstacleHit(obs: ObstacleEntity): boolean {
    if (obs.avoidance === 'jump') {
      // Clear if jumping high enough
      return this.jumpY < 0.36;
    }
    if (obs.avoidance === 'slide') {
      // Clear if sliding low OR jumping super high (actually slide is primary!)
      return !this.isSliding;
    }
    // 'switch' (large_rock) - too tall to jump over
    return true;
  }

  private handleCollision(hitType: ObstacleType): void {
    this.hitstopTimer = 0.06;
    this.hitFlash = 1.0;
    this.shakeTimer = 0.35;
    this.shakeMagnitude = 12;
    this.dizzyTime = 0;

    audioEngine.playCollision();

    const pt = this.renderer.project(0.08, this.laneX, this.laneX);
    this.spawnImpactStars(pt.x, pt.y - 45 * pt.scale);

    const finalScore = Math.floor(this.score);
    const finalDistance = Math.floor(this.distanceMeters);
    const isNewRecord = finalScore > this.bestScoreRef && finalScore > 0;

    audioEngine.setMusicTrack(isNewRecord ? 'newrecord' : 'gameover');
    if (isNewRecord) {
      audioEngine.playCelebration();
    }

    this.setState('GAME_OVER');
    this.callbacks.onGameOver({
      score: finalScore,
      bamboo: this.bambooCount,
      distance: finalDistance,
      hitObstacle: hitType,
    });
  }

  private collectBamboo(col: CollectibleEntity): void {
    col.collected = true;
    col.active = false;

    const isGolden = col.type === 'golden_bamboo';
    const bambooValue = isGolden ? 5 : 1;
    const scoreValue = isGolden ? 50 : 10;

    this.combo += 1;
    this.comboTimer = 1.65;
    const comboBonus = Math.min(this.combo - 1, 5) * 2;

    this.bambooCount += bambooValue;
    this.score += scoreValue + comboBonus;

    audioEngine.playBambooCollect(isGolden, this.combo);

    const pt = this.renderer.project(col.z, col.lane, this.laneX);
    const py = pt.y - (26 + col.yOffset * 58) * pt.scale;
    this.spawnBambooSparkles(pt.x, py, isGolden);
    this.spawnFloatingText(
      pt.x,
      py - 18,
      isGolden ? `+${scoreValue} GOLD!` : `+${bambooValue}`,
      isGolden ? '#FACC15' : '#86EFAC',
      isGolden ? 1.2 : 1.0
    );

    this.pushHudSnapshot(true);
  }

  // ==================== PATTERN GENERATOR ====================

  private spawnNextPattern(): void {
    this.patternIndex += 1;
    const diff = this.speedMultiplier;

    // Pick 1 or 2 blocked lanes max — NEVER block all 3 lanes with non-passable obstacles!
    const laneOrder = [...ALL_LANES].sort(() => Math.random() - 0.5);
    const patternRoll = Math.random();

    if (patternRoll < 0.34) {
      // Pattern A: 1 jumpable obstacle + bamboo arc right over it!
      const lane = laneOrder[0];
      const type = JUMPABLE_TYPES[Math.floor(Math.random() * JUMPABLE_TYPES.length)];
      this.spawnObstacle(type, lane, 1.04);
      this.spawnBamboo(lane, 1.04, 0.55, Math.random() < 0.14);

      // Plus a trail of bamboo in an adjacent clear lane
      const clearLane = laneOrder[1];
      this.spawnBambooLine(clearLane, 1.04, 3, 0.085);
    } else if (patternRoll < 0.58) {
      // Pattern B: High bamboo gate (SLIDE under) with bamboo line underneath!
      const gateLane = laneOrder[0];
      this.spawnObstacle('high_bamboo_gate', gateLane, 1.04);
      this.spawnBambooLine(gateLane, 0.99, 3, 0.075, true);

      if (diff > 1.2 && Math.random() < 0.65) {
        const secondType: ObstacleType = Math.random() < 0.5 ? 'large_rock' : 'wooden_log';
        this.spawnObstacle(secondType, laneOrder[1], 1.04);
      }
    } else if (patternRoll < 0.82) {
      // Pattern C: Two-lane obstacle stagger (1 open safe lane with bamboo!)
      const openLane = laneOrder[0];
      const t1 = this.pickRandomObstacle();
      this.spawnObstacle(t1, laneOrder[1], 1.04);

      if (diff > 1.12 || Math.random() < 0.6) {
        const t2 = this.pickRandomObstacle();
        this.spawnObstacle(t2, laneOrder[2], 1.04);
      }
      this.spawnBambooLine(openLane, 1.02, 4, 0.08);
    } else {
      // Pattern D: Rewarding diagonal bamboo slalom + single boulder
      this.spawnObstacle('large_rock', laneOrder[2], 1.04);
      this.spawnBamboo(laneOrder[0], 1.0, 0, false);
      this.spawnBamboo(laneOrder[1], 1.08, 0, false);
      this.spawnBamboo(laneOrder[0], 1.16, 0, Math.random() < 0.22);
    }
  }

  private pickRandomObstacle(): ObstacleType {
    const pool: ObstacleType[] = [
      'small_rock',
      'large_rock',
      'fallen_bamboo',
      'wooden_log',
      'tree_roots',
      'high_bamboo_gate',
    ];
    return pool[Math.floor(Math.random() * pool.length)];
  }

  private spawnObstacle(type: ObstacleType, lane: LaneIndex, z: number): void {
    for (let i = 0; i < this.obstacles.length; i++) {
      const o = this.obstacles[i];
      if (!o.active) {
        o.active = true;
        o.type = type;
        o.avoidance = OBSTACLE_AVOIDANCE_MAP[type];
        o.lane = lane;
        o.z = z;
        o.passed = false;
        return;
      }
    }
  }

  private spawnBamboo(lane: LaneIndex, z: number, yOffset: number, isGolden: boolean): void {
    for (let i = 0; i < this.collectibles.length; i++) {
      const c = this.collectibles[i];
      if (!c.active) {
        c.active = true;
        c.type = isGolden ? 'golden_bamboo' : 'bamboo';
        c.lane = lane;
        c.z = z;
        c.yOffset = yOffset;
        c.bobPhase = Math.random() * Math.PI * 2;
        c.collected = false;
        return;
      }
    }
  }

  private spawnBambooLine(
    lane: LaneIndex,
    startZ: number,
    count: number,
    spacing: number,
    allowGoldenTail = false
  ): void {
    for (let i = 0; i < count; i++) {
      const isGold = allowGoldenTail && i === count - 1 && Math.random() < 0.22;
      this.spawnBamboo(lane, startZ + i * spacing, 0, isGold);
    }
  }

  // ==================== PARTICLES & FLOATING TEXTS ====================

  private spawnDustBurst(lane: number, z: number, count: number): void {
    const pt = this.renderer.project(z, lane, this.laneX);
    for (let n = 0; n < count; n++) {
      this.allocParticle(
        pt.x + (Math.random() - 0.5) * 28 * pt.scale,
        pt.y + (Math.random() - 0.5) * 6 * pt.scale,
        (Math.random() - 0.5) * 60,
        -25 - Math.random() * 45,
        (4 + Math.random() * 4) * pt.scale,
        0.35 + Math.random() * 0.2,
        'rgba(229, 203, 168, 0.85)',
        'circle'
      );
    }
  }

  private spawnBambooSparkles(x: number, y: number, isGolden: boolean): void {
    this.allocParticle(x, y, 0, 0, 14, 0.35, isGolden ? '#FACC15' : '#86EFAC', 'ring');
    for (let n = 0; n < 8; n++) {
      const angle = (n / 8) * Math.PI * 2 + Math.random() * 0.4;
      const spd = 65 + Math.random() * 85;
      this.allocParticle(
        x,
        y,
        Math.cos(angle) * spd,
        Math.sin(angle) * spd - 30,
        4.5 + Math.random() * 3,
        0.45 + Math.random() * 0.2,
        isGolden ? '#FDE047' : n % 2 === 0 ? '#4ADE80' : '#BBF7D0',
        n % 2 === 0 ? 'leaf' : 'star'
      );
    }
  }

  private spawnImpactStars(x: number, y: number): void {
    for (let n = 0; n < 14; n++) {
      const angle = (n / 14) * Math.PI * 2;
      const spd = 90 + Math.random() * 110;
      this.allocParticle(
        x,
        y,
        Math.cos(angle) * spd,
        Math.sin(angle) * spd - 40,
        5 + Math.random() * 4,
        0.65,
        n % 2 === 0 ? '#FACC15' : '#FB7185',
        'star'
      );
    }
  }

  private allocParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    size: number,
    maxLife: number,
    color: string,
    shape: ParticleEntity['shape']
  ): void {
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.x = x;
        p.y = y;
        p.vx = vx;
        p.vy = vy;
        p.size = size;
        p.life = maxLife;
        p.maxLife = maxLife;
        p.color = color;
        p.shape = shape;
        p.rotation = Math.random() * Math.PI * 2;
        p.vRot = (Math.random() - 0.5) * 8;
        return;
      }
    }
  }

  private spawnFloatingText(
    x: number,
    y: number,
    text: string,
    color: string,
    scale = 1
  ): void {
    for (let i = 0; i < this.floatingTexts.length; i++) {
      const ft = this.floatingTexts[i];
      if (!ft.active) {
        ft.active = true;
        ft.x = x;
        ft.y = y;
        ft.vy = -52;
        ft.text = text;
        ft.color = color;
        ft.life = 0.75;
        ft.maxLife = 0.75;
        ft.scale = scale;
        return;
      }
    }
  }

  private updateParticles(dt: number): void {
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 120 * dt;
      p.rotation += p.vRot * dt;
    }
  }

  private updateFloatingTexts(dt: number): void {
    for (let i = 0; i < this.floatingTexts.length; i++) {
      const ft = this.floatingTexts[i];
      if (!ft.active) continue;
      ft.life -= dt;
      if (ft.life <= 0) {
        ft.active = false;
        continue;
      }
      ft.y += ft.vy * dt;
    }
  }

  // ==================== HUD BRIDGE & RENDER ====================

  private pushHudSnapshot(force: boolean): void {
    const cleanScore = Math.floor(this.score);
    const cleanDist = Math.floor(this.distanceMeters);
    const cleanSpeed = Math.round(this.speedMultiplier * 10) / 10;
    const countVal = Math.max(0, Math.ceil(this.countdownTimer / 0.85));

    if (
      !force &&
      cleanScore === this.lastHudSent.score &&
      this.bambooCount === this.lastHudSent.bamboo &&
      cleanDist === this.lastHudSent.distance &&
      cleanSpeed === this.lastHudSent.speedMultiplier &&
      this.combo === this.lastHudSent.combo
    ) {
      return;
    }

    const snap: HudSnapshot = {
      score: cleanScore,
      bamboo: this.bambooCount,
      distance: cleanDist,
      speedMultiplier: cleanSpeed,
      combo: this.combo,
      countdownValue: countVal,
      isNewRecord: this.passedNewRecordThisRun,
    };
    this.lastHudSent = snap;
    this.callbacks.onHudUpdate(snap);
  }

  private render(): void {
    let shakeX = 0;
    let shakeY = 0;
    if (this.shakeTimer > 0) {
      const decay = this.shakeTimer / 0.35;
      shakeX = (Math.random() - 0.5) * 2 * this.shakeMagnitude * decay;
      shakeY = (Math.random() - 0.5) * 2 * this.shakeMagnitude * decay;
    }

    this.renderer.render(this.ctx, {
      scrollDistance: this.scrollDistance,
      speedMultiplier: this.speedMultiplier,
      shakeX,
      shakeY,
      time: this.elapsedTime,
      player: {
        laneX: this.laneX,
        bankAngle: this.bankAngle,
        jumpY: this.jumpY,
        isSliding: this.isSliding,
        slideProgress: this.isSliding ? 1 - this.slideTimer / this.slideDuration : 0,
        runCycle: this.runCycle,
        squashX: this.squashX,
        squashY: this.squashY,
        state: this.gameState,
        hitFlash: this.hitFlash,
        dizzyTime: this.dizzyTime,
      },
      obstacles: this.obstacles,
      collectibles: this.collectibles,
      particles: this.particles,
      floatingTexts: this.floatingTexts,
    });
  }
}
