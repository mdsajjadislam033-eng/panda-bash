export type GameState =
  | 'LOADING'
  | 'MENU'
  | 'COUNTDOWN'
  | 'PLAYING'
  | 'PAUSED'
  | 'GAME_OVER';

export type Language = 'en' | 'bn';

export type LaneIndex = -1 | 0 | 1;

export type ObstacleType =
  | 'small_rock'
  | 'large_rock'
  | 'fallen_bamboo'
  | 'wooden_log'
  | 'tree_roots'
  | 'high_bamboo_gate';

export type ObstacleAvoidance = 'jump' | 'slide' | 'switch';

export type CollectibleType = 'bamboo' | 'golden_bamboo';

export interface GameSettings {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  musicVolume: number; // 0.0 to 1.0
  sfxVolume: number; // 0.0 to 1.0
  language: Language;
  onScreenControls: boolean;
}

export interface SaveData extends GameSettings {
  bestScore: number;
  totalBamboo: number;
  bestDistance: number;
  totalRuns: number;
}

export interface HudSnapshot {
  score: number;
  bamboo: number;
  distance: number;
  speedMultiplier: number;
  combo: number;
  countdownValue: number; // 3, 2, 1, 0 (GO)
  isNewRecord: boolean;
}

export interface RunSummary {
  score: number;
  bamboo: number;
  distance: number;
  bestScore: number;
  totalBamboo: number;
  isNewRecord: boolean;
  hitObstacle: ObstacleType | null;
}

export interface ObstacleEntity {
  active: boolean;
  type: ObstacleType;
  avoidance: ObstacleAvoidance;
  lane: LaneIndex;
  z: number; // 1.0 (horizon) -> 0.0 (player) -> -0.25 (behind camera)
  passed: boolean;
}

export interface CollectibleEntity {
  active: boolean;
  type: CollectibleType;
  lane: LaneIndex;
  z: number;
  yOffset: number; // 0 = ground, >0 = elevated (arc over jumpables)
  bobPhase: number;
  collected: boolean;
}

export interface ParticleEntity {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  shape: 'circle' | 'leaf' | 'star' | 'ring';
  rotation: number;
  vRot: number;
}

export interface FloatingTextEntity {
  active: boolean;
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
  scale: number;
}
