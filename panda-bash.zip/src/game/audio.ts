import { GameSettings } from './types';

export type MusicTrack = 'none' | 'menu' | 'gameplay' | 'gameover' | 'newrecord';

// Pentatonic C-major / D-minor Asian bamboo forest scales (frequencies in Hz)
const SCALE_PENTATONIC = {
  C3: 130.81,
  D3: 146.83,
  E3: 164.81,
  G3: 196.0,
  A3: 220.0,
  C4: 261.63,
  D4: 293.66,
  E4: 329.63,
  G4: 392.0,
  A4: 440.0,
  C5: 523.25,
  D5: 587.33,
  E5: 659.25,
  G5: 783.99,
  A5: 880.0,
  C6: 1046.5,
};

const MENU_MELODY: (number | null)[] = [
  SCALE_PENTATONIC.E4, null, SCALE_PENTATONIC.G4, SCALE_PENTATONIC.A4,
  SCALE_PENTATONIC.C5, null, SCALE_PENTATONIC.A4, SCALE_PENTATONIC.G4,
  SCALE_PENTATONIC.E4, null, SCALE_PENTATONIC.D4, SCALE_PENTATONIC.E4,
  SCALE_PENTATONIC.G4, null, null, null,
  SCALE_PENTATONIC.A4, null, SCALE_PENTATONIC.C5, SCALE_PENTATONIC.D5,
  SCALE_PENTATONIC.E5, null, SCALE_PENTATONIC.D5, SCALE_PENTATONIC.C5,
  SCALE_PENTATONIC.A4, null, SCALE_PENTATONIC.G4, SCALE_PENTATONIC.E4,
  SCALE_PENTATONIC.D4, null, SCALE_PENTATONIC.C4, null,
];

const MENU_BASS: (number | null)[] = [
  SCALE_PENTATONIC.C3, null, null, null,
  SCALE_PENTATONIC.G3, null, null, null,
  SCALE_PENTATONIC.A3, null, null, null,
  SCALE_PENTATONIC.G3, null, null, null,
  SCALE_PENTATONIC.C3, null, null, null,
  SCALE_PENTATONIC.G3, null, null, null,
  SCALE_PENTATONIC.A3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.C3, null, null, null,
];

const GAMEPLAY_MELODY: (number | null)[] = [
  SCALE_PENTATONIC.C5, null, SCALE_PENTATONIC.E5, SCALE_PENTATONIC.G5,
  null, SCALE_PENTATONIC.E5, SCALE_PENTATONIC.D5, SCALE_PENTATONIC.C5,
  SCALE_PENTATONIC.A4, null, SCALE_PENTATONIC.C5, SCALE_PENTATONIC.D5,
  SCALE_PENTATONIC.E5, null, SCALE_PENTATONIC.G4, null,
  SCALE_PENTATONIC.C5, SCALE_PENTATONIC.D5, SCALE_PENTATONIC.E5, null,
  SCALE_PENTATONIC.G5, null, SCALE_PENTATONIC.A5, SCALE_PENTATONIC.G5,
  SCALE_PENTATONIC.E5, null, SCALE_PENTATONIC.D5, SCALE_PENTATONIC.C5,
  SCALE_PENTATONIC.D5, null, SCALE_PENTATONIC.C5, null,
];

const GAMEPLAY_BASS: (number | null)[] = [
  SCALE_PENTATONIC.C3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.C3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.A3, null, SCALE_PENTATONIC.E3, null,
  SCALE_PENTATONIC.G3, null, SCALE_PENTATONIC.D3, null,
  SCALE_PENTATONIC.C3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.E3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.A3, null, SCALE_PENTATONIC.G3, null,
  SCALE_PENTATONIC.C3, null, SCALE_PENTATONIC.G3, null,
];

const GAMEPLAY_COUNTER: (number | null)[] = [
  null, SCALE_PENTATONIC.G5, null, SCALE_PENTATONIC.A5,
  SCALE_PENTATONIC.G5, null, null, SCALE_PENTATONIC.E5,
  null, SCALE_PENTATONIC.E5, null, SCALE_PENTATONIC.G5,
  null, SCALE_PENTATONIC.C6, null, null,
  null, SCALE_PENTATONIC.G5, null, SCALE_PENTATONIC.A5,
  null, SCALE_PENTATONIC.C6, null, SCALE_PENTATONIC.A5,
  null, SCALE_PENTATONIC.G5, null, SCALE_PENTATONIC.E5,
  null, SCALE_PENTATONIC.G5, null, null,
];

class PandaAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  private musicEnabled = true;
  private sfxEnabled = true;
  private musicVolume = 0.55;
  private sfxVolume = 0.75;

  private currentTrack: MusicTrack = 'none';
  private schedulerId: number | null = null;
  private nextNoteTime = 0;
  private currentStep = 0;
  private speedIntensity = 1.0; // >= 1.45 triggers cheerful arcade intensity layer

  // SFX cooldown throttling (ms)
  private lastSfxTime: Record<string, number> = {};
  private footstepLeft = true;

  public applySettings(settings: Pick<GameSettings, 'musicEnabled' | 'sfxEnabled' | 'musicVolume' | 'sfxVolume'>): void {
    this.musicEnabled = settings.musicEnabled;
    this.sfxEnabled = settings.sfxEnabled;
    this.musicVolume = settings.musicVolume;
    this.sfxVolume = settings.sfxVolume;
    this.syncGains();
  }

  public unlock(): void {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 1.0;
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.connect(this.masterGain);

      this.noiseBuffer = this.createNoiseBuffer(this.ctx);
      this.syncGains();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume().catch(() => {});
    }
  }

  private createNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const length = Math.floor(ctx.sampleRate * 0.6);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private syncGains(): void {
    if (!this.ctx || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const mVol = this.musicEnabled ? this.musicVolume * 0.42 : 0;
    const sVol = this.sfxEnabled ? this.sfxVolume * 0.85 : 0;
    this.musicGain.gain.setTargetAtTime(mVol, now, 0.04);
    this.sfxGain.gain.setTargetAtTime(sVol, now, 0.02);
  }

  public setSpeedIntensity(speedMult: number): void {
    this.speedIntensity = speedMult;
  }

  public setMusicTrack(track: MusicTrack): void {
    if (this.currentTrack === track) return;
    this.currentTrack = track;
    this.stopMusicLoop();

    if (track === 'none') return;
    this.unlock();
    if (!this.ctx) return;

    if (track === 'gameover') {
      this.playGameOverJingle();
      return;
    }
    if (track === 'newrecord') {
      this.playNewRecordFanfare();
      return;
    }

    // Looping tracks: 'menu' and 'gameplay'
    this.currentStep = 0;
    this.nextNoteTime = this.ctx.currentTime + 0.06;
    this.schedulerId = window.setInterval(() => this.scheduleLoopStep(), 28);
  }

  public suspendOnHide(): void {
    if (this.ctx && this.ctx.state === 'running') {
      void this.ctx.suspend().catch(() => {});
    }
  }

  public resumeOnShow(): void {
    if (this.ctx && this.ctx.state === 'suspended' && (this.musicEnabled || this.sfxEnabled)) {
      void this.ctx.resume().catch(() => {});
    }
  }

  public dispose(): void {
    this.stopMusicLoop();
    if (this.ctx) {
      void this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }

  private stopMusicLoop(): void {
    if (this.schedulerId !== null) {
      window.clearInterval(this.schedulerId);
      this.schedulerId = null;
    }
  }

  private scheduleLoopStep(): void {
    if (!this.ctx || !this.musicGain || this.ctx.state !== 'running') return;
    const lookahead = 0.14;
    while (this.nextNoteTime < this.ctx.currentTime + lookahead) {
      if (this.musicEnabled && this.musicVolume > 0.01) {
        if (this.currentTrack === 'menu') {
          this.triggerMenuStep(this.currentStep, this.nextNoteTime);
        } else if (this.currentTrack === 'gameplay') {
          this.triggerGameplayStep(this.currentStep, this.nextNoteTime);
        }
      }
      const bpm =
        this.currentTrack === 'menu'
          ? 104
          : Math.min(156, 128 + Math.max(0, this.speedIntensity - 1) * 24);
      const stepDuration = 60 / bpm / 2; // eighth-note grid
      this.nextNoteTime += stepDuration;
      this.currentStep = (this.currentStep + 1) % 32;
    }
  }

  private triggerMenuStep(step: number, time: number): void {
    const mel = MENU_MELODY[step];
    const bass = MENU_BASS[step];
    if (mel) {
      this.playBambooFluteNote(mel, time, 0.28, 0.22);
    }
    if (bass) {
      this.playMarimbaNote(bass, time, 0.32, 0.24);
    }
    if (step % 4 === 0) {
      this.playWoodblock(time, step % 8 === 0 ? 540 : 680, 0.08);
    }
  }

  private triggerGameplayStep(step: number, time: number): void {
    const mel = GAMEPLAY_MELODY[step];
    const bass = GAMEPLAY_BASS[step];
    const arcadeLayer = this.speedIntensity >= 1.38;

    if (mel) {
      this.playMarimbaNote(mel, time, 0.19, 0.24);
      if (arcadeLayer) {
        this.playBambooFluteNote(mel, time, 0.14, 0.11);
      }
    }
    if (bass) {
      this.playBassPulse(bass, time, 0.2, 0.26);
    }
    if (arcadeLayer) {
      const counter = GAMEPLAY_COUNTER[step];
      if (counter) {
        this.playMarimbaNote(counter, time, 0.12, 0.13);
      }
      // Crisp arcade hi-hat pulse
      if (step % 2 === 1) {
        this.playShaker(time, 0.06);
      }
    }
    // Kick / woodblock groove
    if (step % 4 === 0) {
      this.playSoftKick(time, 0.24);
    }
    if (step % 4 === 2) {
      this.playWoodblock(time, 760, 0.1);
    }
  }

  private playBambooFluteNote(freq: number, time: number, dur: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(freq * 2, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2200, time);

    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.linearRampToValueAtTime(vol, time + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);

    const g2 = this.ctx.createGain();
    g2.gain.value = 0.2;

    osc.connect(filter);
    osc2.connect(g2);
    g2.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);

    osc.start(time);
    osc2.start(time);
    osc.stop(time + dur + 0.02);
    osc2.stop(time + dur + 0.02);
  }

  private playMarimbaNote(freq: number, time: number, dur: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, time);

    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.linearRampToValueAtTime(vol, time + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);

    osc.connect(gain);
    gain.connect(this.musicGain);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private playBassPulse(freq: number, time: number, dur: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(420, time);

    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.linearRampToValueAtTime(vol, time + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private playSoftKick(time: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, time);
    osc.frequency.exponentialRampToValueAtTime(46, time + 0.09);

    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.11);

    osc.connect(gain);
    gain.connect(this.musicGain);
    osc.start(time);
    osc.stop(time + 0.12);
  }

  private playWoodblock(time: number, pitch: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(pitch, time);
    osc.frequency.exponentialRampToValueAtTime(pitch * 0.72, time + 0.045);

    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.055);

    osc.connect(gain);
    gain.connect(this.musicGain);
    osc.start(time);
    osc.stop(time + 0.06);
  }

  private playShaker(time: number, vol: number): void {
    if (!this.ctx || !this.musicGain || !this.noiseBuffer) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(5200, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.035);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);
    src.start(time);
    src.stop(time + 0.04);
  }

  private playGameOverJingle(): void {
    if (!this.ctx || !this.musicGain || !this.musicEnabled) return;
    const now = this.ctx.currentTime + 0.04;
    const notes = [392, 349.23, 329.63, 261.63];
    notes.forEach((freq, i) => {
      const t = now + i * 0.22;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      if (i === notes.length - 1) {
        osc.frequency.linearRampToValueAtTime(freq * 0.86, t + 0.45);
      }
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.linearRampToValueAtTime(0.28, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + (i === notes.length - 1 ? 0.5 : 0.2));
      osc.connect(gain);
      gain.connect(this.musicGain!);
      osc.start(t);
      osc.stop(t + 0.55);
    });
  }

  private playNewRecordFanfare(): void {
    if (!this.ctx || !this.musicGain || !this.musicEnabled) return;
    const now = this.ctx.currentTime + 0.04;
    const notes = [
      SCALE_PENTATONIC.C5,
      SCALE_PENTATONIC.E5,
      SCALE_PENTATONIC.G5,
      SCALE_PENTATONIC.C6,
      SCALE_PENTATONIC.A5,
      SCALE_PENTATONIC.C6,
    ];
    const offsets = [0, 0.11, 0.22, 0.34, 0.52, 0.66];
    notes.forEach((freq, i) => {
      const t = now + offsets[i];
      const dur = i === notes.length - 1 ? 0.65 : 0.18;
      this.playBambooFluteNote(freq, t, dur, 0.32);
      this.playMarimbaNote(freq, t, dur, 0.24);
    });
  }

  // ==================== SOUND EFFECTS ====================

  private canTrigger(key: string, cooldownMs: number): boolean {
    if (!this.sfxEnabled || this.sfxVolume <= 0.01) return false;
    this.unlock();
    if (!this.ctx || !this.sfxGain) return false;
    const now = performance.now();
    const prev = this.lastSfxTime[key] || 0;
    if (now - prev < cooldownMs) return false;
    this.lastSfxTime[key] = now;
    return true;
  }

  public playButtonClick(): void {
    if (!this.canTrigger('click', 45)) return;
    const now = this.ctx!.currentTime;
    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(680, now);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.045);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.055);
  }

  public playFootstep(): void {
    if (!this.canTrigger('step', 125)) return;
    const now = this.ctx!.currentTime;
    const baseFreq = this.footstepLeft ? 105 : 122;
    this.footstepLeft = !this.footstepLeft;

    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(48, now + 0.055);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.065);
  }

  public playLaneSwitch(): void {
    if (!this.canTrigger('lane', 70)) return;
    const now = this.ctx!.currentTime;
    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(240, now);
    osc.frequency.exponentialRampToValueAtTime(360, now + 0.06);
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.075);
  }

  public playJump(): void {
    if (!this.canTrigger('jump', 90)) return;
    const now = this.ctx!.currentTime;
    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(210, now);
    osc.frequency.exponentialRampToValueAtTime(590, now + 0.16);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.19);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  public playSlide(): void {
    if (!this.canTrigger('slide', 120)) return;
    const now = this.ctx!.currentTime;
    // Filtered air brush + low swoop
    if (this.noiseBuffer) {
      const src = this.ctx!.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx!.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1400, now);
      filter.frequency.exponentialRampToValueAtTime(420, now + 0.22);
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0.2, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.24);
      src.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain!);
      src.start(now);
      src.stop(now + 0.25);
    }
    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(135, now + 0.18);
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.21);
  }

  public playBambooCollect(isGolden: boolean, combo: number): void {
    if (!this.canTrigger('bamboo', 55)) return;
    const now = this.ctx!.currentTime;
    const pitchBoost = Math.min(combo, 10) * 28;

    // 1. Bright Bamboo Collection Chime
    const osc = this.ctx!.createOscillator();
    const gain = this.ctx!.createGain();
    osc.type = 'sine';
    const f1 = (isGolden ? 784 : 587) + pitchBoost;
    osc.frequency.setValueAtTime(f1, now);
    osc.frequency.exponentialRampToValueAtTime(f1 * 1.35, now + 0.09);
    gain.gain.setValueAtTime(0.26, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start(now);
    osc.stop(now + 0.17);

    // 2. Crisp Bamboo Crunch (filtered noise burst)
    if (this.noiseBuffer) {
      const src = this.ctx!.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx!.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2600, now);
      filter.Q.value = 2.5;
      const ng = this.ctx!.createGain();
      ng.gain.setValueAtTime(0.22, now);
      ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.065);
      src.connect(filter);
      filter.connect(ng);
      ng.connect(this.sfxGain!);
      src.start(now);
      src.stop(now + 0.07);
    }

    // 3. Bamboo Pop (bubble pop on combo or golden bamboo)
    if (isGolden || combo >= 3) {
      const pop = this.ctx!.createOscillator();
      const pg = this.ctx!.createGain();
      pop.type = 'sine';
      pop.frequency.setValueAtTime(520, now + 0.04);
      pop.frequency.exponentialRampToValueAtTime(1180, now + 0.11);
      pg.gain.setValueAtTime(0.2, now + 0.04);
      pg.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);
      pop.connect(pg);
      pg.connect(this.sfxGain!);
      pop.start(now + 0.04);
      pop.stop(now + 0.15);
    }
  }

  public playCollision(): void {
    if (!this.canTrigger('hit', 150)) return;
    const now = this.ctx!.currentTime;

    // Heavy impact thud
    const thud = this.ctx!.createOscillator();
    const tg = this.ctx!.createGain();
    thud.type = 'sawtooth';
    thud.frequency.setValueAtTime(150, now);
    thud.frequency.exponentialRampToValueAtTime(38, now + 0.24);
    tg.gain.setValueAtTime(0.42, now);
    tg.gain.exponentialRampToValueAtTime(0.0001, now + 0.26);
    thud.connect(tg);
    tg.connect(this.sfxGain!);
    thud.start(now);
    thud.stop(now + 0.27);

    // Noise smash
    if (this.noiseBuffer) {
      const src = this.ctx!.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx!.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(950, now);
      const ng = this.ctx!.createGain();
      ng.gain.setValueAtTime(0.32, now);
      ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
      src.connect(filter);
      filter.connect(ng);
      ng.connect(this.sfxGain!);
      src.start(now);
      src.stop(now + 0.19);
    }

    // Funny cartoon dizzy warble reaction slightly after impact
    const boing = this.ctx!.createOscillator();
    const bg = this.ctx!.createGain();
    boing.type = 'triangle';
    boing.frequency.setValueAtTime(460, now + 0.14);
    boing.frequency.linearRampToValueAtTime(310, now + 0.24);
    boing.frequency.linearRampToValueAtTime(420, now + 0.34);
    boing.frequency.linearRampToValueAtTime(220, now + 0.48);
    bg.gain.setValueAtTime(0.0001, now + 0.14);
    bg.gain.linearRampToValueAtTime(0.24, now + 0.17);
    bg.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);
    boing.connect(bg);
    bg.connect(this.sfxGain!);
    boing.start(now + 0.14);
    boing.stop(now + 0.52);
  }

  public playPause(isPausing: boolean): void {
    if (!this.canTrigger('pause', 80)) return;
    const now = this.ctx!.currentTime;
    const f1 = isPausing ? 523.25 : 392.0;
    const f2 = isPausing ? 392.0 : 523.25;

    [f1, f2].forEach((freq, idx) => {
      const t = now + idx * 0.065;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t);
      osc.stop(t + 0.12);
    });
  }

  public playCountdownTick(go: boolean): void {
    if (!this.canTrigger('countdown', 100)) return;
    const now = this.ctx!.currentTime;
    const freqs = go ? [523.25, 659.25, 783.99] : [440];
    freqs.forEach((f) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = go ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime(go ? 0.2 : 0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + (go ? 0.32 : 0.14));
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(now);
      osc.stop(now + 0.35);
    });
  }

  public playCelebration(): void {
    if (!this.canTrigger('celebrate', 400)) return;
    const now = this.ctx!.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, idx) => {
      const t = now + idx * 0.075;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, t);
      gain.gain.setValueAtTime(0.22, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t);
      osc.stop(t + 0.3);
    });
  }
}

export const audioEngine = new PandaAudioEngine();
