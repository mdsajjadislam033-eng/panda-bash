import { Language, ObstacleType } from './types';

export interface Translations {
  gameTitle: string;
  gameSubtitle: string;
  loading: string;
  play: string;
  settings: string;
  howToPlay: string;
  bestScore: string;
  totalBamboo: string;
  score: string;
  bamboo: string;
  distance: string;
  speed: string;
  pause: string;
  paused: string;
  resume: string;
  restart: string;
  mainMenu: string;
  soundSettings: string;
  gameOver: string;
  newRecord: string;
  finalScore: string;
  bambooCollected: string;
  distanceTravelled: string;
  personalBest: string;
  playAgain: string;
  home: string;
  music: string;
  sfx: string;
  musicVolume: string;
  sfxVolume: string;
  language: string;
  onScreenButtons: string;
  on: string;
  off: string;
  close: string;
  back: string;
  countdownGo: string;
  controlHintDesktop: string;
  controlHintMobile: string;
  controlsTitle: string;
  controlsMove: string;
  controlsJump: string;
  controlsSlide: string;
  controlsPause: string;
  obstaclesTitle: string;
  tipJump: string;
  tipSlide: string;
  tipSwitch: string;
  tipBamboo: string;
  funnyReactions: Record<ObstacleType | 'default', string>;
  leftBtn: string;
  rightBtn: string;
  jumpBtn: string;
  slideBtn: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    gameTitle: 'PANDA BAMBOO',
    gameSubtitle: 'Bamboo Forest Runner',
    loading: 'Loading the bamboo forest...',
    play: 'Play',
    settings: 'Settings',
    howToPlay: 'How to Play',
    bestScore: 'Best Score',
    totalBamboo: 'Total Bamboo',
    score: 'Score',
    bamboo: 'Bamboo',
    distance: 'Distance',
    speed: 'Speed',
    pause: 'Pause',
    paused: 'Paused',
    resume: 'Resume',
    restart: 'Restart',
    mainMenu: 'Main Menu',
    soundSettings: 'Audio & Settings',
    gameOver: 'Bamboozled!',
    newRecord: 'New Personal Best!',
    finalScore: 'Final Score',
    bambooCollected: 'Bamboo Collected',
    distanceTravelled: 'Distance',
    personalBest: 'Personal Best',
    playAgain: 'Play Again',
    home: 'Main Menu',
    music: 'Music',
    sfx: 'Sound Effects',
    musicVolume: 'Music Volume',
    sfxVolume: 'SFX Volume',
    language: 'Language',
    onScreenButtons: 'On-Screen Touch Buttons',
    on: 'ON',
    off: 'OFF',
    close: 'Done',
    back: 'Back',
    countdownGo: 'RUN!',
    controlHintDesktop: 'A/D or Arrows Move · W/Up/Space Jump · S/Down Slide · Esc Pause',
    controlHintMobile: 'Swipe Left/Right to Switch Lanes · Swipe Up to Jump · Swipe Down to Slide',
    controlsTitle: 'Controls',
    controlsMove: 'Switch Lanes: Swipe Left/Right or A / D / Left & Right Arrows',
    controlsJump: 'Jump: Swipe Up or W / Up Arrow / Space',
    controlsSlide: 'Slide & Fast-Fall: Swipe Down or S / Down Arrow',
    controlsPause: 'Pause: Tap Pause button or press Esc / P',
    obstaclesTitle: 'Forest Obstacles & Bamboo',
    tipJump: 'Jump over Small Rocks, Fallen Bamboo, Wooden Logs & Tree Roots.',
    tipSlide: 'Slide under Hanging Bamboo Gates with fluttering ribbons.',
    tipSwitch: 'Switch lanes around towering Large Boulders!',
    tipBamboo: 'Grab green bamboo (+10) & rare golden lucky bamboo (+50)!',
    funnyReactions: {
      small_rock: 'Stubbed a chubby panda toe on a sneaky pebble!',
      large_rock: 'That boulder definitely won the staring contest.',
      fallen_bamboo: 'Tripped over the snack pile! Almost ate it though.',
      wooden_log: 'Bonked right into a mossy forest log!',
      tree_roots: 'Tangled in sneaky jungle roots!',
      high_bamboo_gate: 'Forgot to duck under the bamboo crossbar!',
      default: 'Oof! What a dizzy forest tumble!',
    },
    leftBtn: 'Left',
    rightBtn: 'Right',
    jumpBtn: 'Jump',
    slideBtn: 'Slide',
  },
  bn: {
    gameTitle: 'PANDA BAMBOO',
    gameSubtitle: 'জঙ্গল দৌড়',
    loading: 'বাঁশের জঙ্গল প্রস্তুত হচ্ছে...',
    play: 'খেলা শুরু',
    settings: 'সেটিংস',
    howToPlay: 'খেলার নিয়ম',
    bestScore: 'সর্বোচ্চ স্কোর',
    totalBamboo: 'মোট বাঁশ',
    score: 'স্কোর',
    bamboo: 'বাঁশ',
    distance: 'দূরত্ব',
    speed: 'গতি',
    pause: 'বিরতি',
    paused: 'খেলা থামানো হয়েছে',
    resume: 'আবার শুরু',
    restart: 'নতুন করে',
    mainMenu: 'মূল মেনু',
    soundSettings: 'সাউন্ড ও সেটিংস',
    gameOver: 'ধাক্কা লেগেছে!',
    newRecord: 'নতুন রেকর্ড!',
    finalScore: 'মোট স্কোর',
    bambooCollected: 'সংগৃহীত বাঁশ',
    distanceTravelled: 'অতিক্রান্ত দূরত্ব',
    personalBest: 'ব্যক্তিগত সেরা',
    playAgain: 'আবার খেলুন',
    home: 'মূল মেনু',
    music: 'ব্যাকগ্রাউন্ড মিউজিক',
    sfx: 'সাউন্ড ইফেক্ট',
    musicVolume: 'মিউজিক ভলিউম',
    sfxVolume: 'সাউন্ড ভলিউম',
    language: 'ভাষা (Language)',
    onScreenButtons: 'অন-স্ক্রিন টাচ বাটন',
    on: 'চালু',
    off: 'বন্ধ',
    close: 'সম্পন্ন',
    back: 'ফিরে যান',
    countdownGo: 'দৌড়াও!',
    controlHintDesktop: 'A/D বা তীর: লেন পরিবর্তন · W/Space: লাফ · S/Down: স্লাইড · Esc: বিরতি',
    controlHintMobile: 'বামে/ডানে সোয়াইপ: লেন · উপরে সোয়াইপ: লাফ · নিচে সোয়াইপ: স্লাইড',
    controlsTitle: 'কন্ট্রোল নির্দেশনা',
    controlsMove: 'লেন পরিবর্তন: বামে/ডানে সোয়াইপ অথবা A / D / বাম-ডান তীর',
    controlsJump: 'লাফ: উপরে সোয়াইপ অথবা W / উপরের তীর / Space',
    controlsSlide: 'স্লাইড ও দ্রুত নামা: নিচে সোয়াইপ অথবা S / নিচের তীর',
    controlsPause: 'বিরতি: পজ বাটন অথবা Esc / P চাপুন',
    obstaclesTitle: 'বাধা ও বাঁশ সংগ্রহ',
    tipJump: 'ছোট পাথর, পড়া বাঁশ, কাঠের গুঁড়ি ও গাছের শিকড়ের উপর দিয়ে লাফ দিন।',
    tipSlide: 'উঁচু ঝুলন্ত বাঁশের গেটের নিচ দিয়ে স্লাইড করে পার হোন।',
    tipSwitch: 'বড় পাথরের সামনে পড়লে বাম বা ডান লেনে সরে যান!',
    tipBamboo: 'সবুজ বাঁশ (+১০) এবং সোনালি বাঁশ (+৫০) সংগ্রহ করুন!',
    funnyReactions: {
      small_rock: 'ইশ! ছোট পাথরের সাথে পাণ্ডার আঙুলে টোকা লেগেছে!',
      large_rock: 'বিশাল পাথরটা একটুও নড়ল না, পাণ্ডাই ছিটকে গেল!',
      fallen_bamboo: 'বাঁশ খেতে গিয়ে বাঁশেই হোঁচট খেল!',
      wooden_log: 'শ্যাওলা ধরা কাঠের গুঁড়িতে ধপাস!',
      tree_roots: 'গাছের শিকড়ে পা আটকে ডিগবাজি!',
      high_bamboo_gate: 'উঁচু বাঁশের গেটের নিচে মাথা নিচু করতে ভুলে গেছে!',
      default: 'উফ! দারুণ এক মজার ডিগবাজি খেয়েছে পাণ্ডা!',
    },
    leftBtn: 'বাম',
    rightBtn: 'ডান',
    jumpBtn: 'লাফ',
    slideBtn: 'স্লাইড',
  },
};
